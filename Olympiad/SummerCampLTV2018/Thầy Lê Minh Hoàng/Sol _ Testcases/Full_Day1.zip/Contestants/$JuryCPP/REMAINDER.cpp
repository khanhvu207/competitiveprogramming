/*
#Divide and Conquer, #Modular Multiplication Trick
*/
#define taskname "REMAINDER"
#include <iostream>
#include <cstdio>
using namespace std;
typedef long long lli;
typedef unsigned long long llu;
lli x, n, m;

lli Mul(lli x, lli y)
{
    x %= m; y %= m;
    lli q = (long double) x * y / m;
    lli r = (x * y - q * m) % m;
    if (r < 0) r += m;
    return r;
}

//p^0 + p^1 + ... + p^(n - 1) modulo m
lli SumOfPowers(lli p, lli n)
{
    if (n == 1) return 1;
    if (n % 2 == 0)
        return Mul(p + 1, SumOfPowers(Mul(p, p), n / 2));
    else
        return (1 + Mul(p, SumOfPowers(p, n - 1))) % m;
}

void Solve()
{
    cin >> x >> n >> m;
    lli p = 1;
    for (lli temp = x; temp > 0; temp /= 10)
        p = (llu)p * 10UL % (llu)m;
    cout << Mul(x, SumOfPowers(p, n)) << '\n';
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen(taskname".inp", "r", stdin);
    freopen(taskname".out", "w", stdout);
    int nTests;
    cin >> nTests;
    for (; nTests > 0; --nTests)
        Solve();
}
