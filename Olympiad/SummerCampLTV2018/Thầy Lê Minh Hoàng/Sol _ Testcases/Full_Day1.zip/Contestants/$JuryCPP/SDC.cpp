/*
#Bellman-Ford
*/
#define taskname "SDC"
#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
const int maxN = 1001;
int n, m, a, b, lim;
struct TEdge
{
    int u, v, w;
};
vector<TEdge> edges;
int d[maxN];


void Enter()
{
    cin >> n >> m >> a >> b;
    lim = b - a;
    edges.resize(m);
    for (TEdge& e: edges)
        cin >> e.u >> e.v >> e.w;
    fill(d + 1, d + n + 1, 0);
}

inline bool Relax(const TEdge& e)
{
    if (d[e.v] > d[e.u] + e.w)
    {
        d[e.v] = d[e.u] + e.w;
        return true;
    }
    return false;
}

bool BellmanFord()
{
    bool Stop;
    for (int counter = 0; counter < n; ++counter)
    {
        Stop = true;
        for (const TEdge& e: edges)
        {
            if (Relax(e)) Stop = false;
            if (d[e.v] < -lim) return false;
        }
    }
    return Stop;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen(taskname".inp", "r", stdin);
    freopen(taskname".out", "w", stdout);
    Enter();
    if (!BellmanFord())
        cout << "NO";
    else
    {
        cout << "YES\n";
        for (int i = 1; i <= n; ++i) cout << d[i] + b << ' ';
    }
}
