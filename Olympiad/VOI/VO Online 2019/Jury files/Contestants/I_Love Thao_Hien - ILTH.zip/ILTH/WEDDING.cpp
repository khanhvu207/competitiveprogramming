// ILTH
#include <bits/stdc++.h>
#define FORU(i,a,b) for(long long i = (a); i<=(b); i++)
#define FORD(i,a,b) for(long long i = (a); i>=(b); i--)
using namespace std;

int main(){
    freopen("WEDDING.INP","r",stdin);
    freopen("WEDDING.OUT","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    cout << "NO";
    return 0;
}
