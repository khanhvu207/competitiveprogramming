#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;

int main() {
    freopen("share.inp", "r", stdin);
    freopen("share.out", "w", stdout);
    int n;
    long long M;
    cin >> n >> M;
    pair <int, int> a[n];
    long long tmp = 0;
    for (int i = 0; i < n; i++)
        cin >> a[i].first, a[i].second = i, tmp += a[i].first;
    if (tmp < M) {cout << -1; return 0;}
    sort(a, a+n);
    long long cnt = 0, out[n];
    for (int i = 0; i < n; i++) {
        long long l = 0, r = a[i].first-cnt, _;
        while (l <= r) {
            long long m = (l+r)/2;
            if (m*(n-i) > M) r = m-1;
            else _ = m, l = m+1;
        }
        M -= _*(n-i);
        cnt += _;
        out[a[i].second] = cnt;
    }
    for (int i = 0; i < n; i++)
        cout << out[i] << ' ';
    return 0;
}
