#include <stdio.h>
#include <math.h>

using namespace std;

int main() {
    freopen("field.inp", "r", stdin);
    freopen("field.out", "w", stdout);
    int m, n;
    scanf("%d%d", &m, &n);
    int a[m+1][n+1];
    for (int i = 1; i <= m; i++)
        for (int j = 1; j <= n; j++)
            scanf("%d", &a[i][j]);
    int j = 1, cnt = 0;
    for (int i = 1; i <= m; i++) {
        for (j = j; j <= ceil((double) n/m*i); j++) cnt += a[i][j];
        j -= (ceil((double) n/m*i) > (double) n/m*i);
    }
    printf("%d", cnt);
    return 0;
}
