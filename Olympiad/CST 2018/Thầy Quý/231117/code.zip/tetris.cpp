#include <iostream>
#include <cstdio>
using namespace std;

int n, mau[255], cnt[255];
long long mu[255][6], dp[255][255][255];

void init(){
    for (int i = 1; i <= 250; i++){
        mu[i][0] = 1;
        for (int j = 1; j <= 5; j++) mu[i][j] = mu[i][j-1]*i;
    }
}

long long tinh(int l, int r, int k){
    if (l > r) return 0;
    if (dp[l][r][k] != -1) return dp[l][r][k];
    if (l==r) return 1LL * mu[k + cnt[r]][mau[r]];

    dp[l][r][k] = tinh(l,r-1,0) + tinh(r,r,k);
    for (int i = l; i < r; i++)
        if (mau[i] == mau[r])
            dp[l][r][k] = max(dp[l][r][k] , tinh(l,i,k + cnt[r]) + tinh(i+1,r-1,0));

    return dp[l][r][k];
}

int main()
{
    freopen("TETRIS.INP","r",stdin);
    freopen("TETRIS.OUT","w",stdout);

init();
while (scanf("%d", &n) == 1)
{
    int m = 0; mau[0] = 0;
    for (int i = 0; i < n; i++){
        int x; scanf("%d", &x);
        if (x != mau[m]) m++, mau[m] = x, cnt[m] = 1; else cnt[m]++;
    }

    for (int i = 1; i <= m; i++)
        for (int j = 1; j <= m; j++)
            for (int z = 0; z <= 250; z++) dp[i][j][z] = -1;

    printf("%lld\n", tinh(1,m,0));
}

    return 0;
}
