#include <iostream>
#include <cstdio>
using namespace std;

int xoai[1505][1505], cam[1505][1505], dp[1505][1505];
int n,m;

int main()
{
    freopen("GARDEN.INP","r",stdin);
    freopen("GARDEN.OUT","w",stdout);

    cin >> n >> m;

    for (int i = 0; i <= n; i++)
        for (int j = 0; j <= m; j++) dp[i][j] = -1e9, cam[i][j] = xoai[i][j] = 0;
    dp[0][0] = 0;

    for (int i = 1; i <= n; i++)
    {
        string s;
        for (int j = 1; j <= m; j++){
            cin >> s;
            if (s[0] == 'X'){
                if (s.length() == 3) xoai[i][j] = xoai[i][j-1] + ((int)s[1]-48)*10 + (int)s[2]-48;
                else xoai[i][j] = xoai[i][j-1] + (int)s[1]-48;
                cam[i][j] = cam[i][j-1];
            }
            else {
                if (s.length() == 3) cam[i][j] = cam[i][j-1] + ((int)s[1]-48)*10 + (int)s[2]-48;
                else cam[i][j] = cam[i][j-1] + (int)s[1]-48;
                xoai[i][j] = xoai[i][j-1];
            }
        }
    }

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) {
            dp[i][j] = max(dp[i-1][j] , dp[i-1][j-1]) + cam[i][j-1] + xoai[i][m] - xoai[i][j];
            dp[i][j] = max(dp[i][j] , dp[i][j-1] - xoai[i][j] + xoai[i][j-1]);
        }

    cout << dp[n][m] << "\n";
    return 0;
}
