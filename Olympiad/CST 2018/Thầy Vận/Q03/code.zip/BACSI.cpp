#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <cstdio>
#include <queue>
#include <iomanip>
#include <stack>
#include <queue>
#include <cstring>
#include <string>
#include <cmath>

using namespace std;

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,n) for(int i = 0; i < n; i++)
#define REPD(i,n) for(int i = n - 1; i >= 0; i--)

#define ALL(x) (x).begin(), (x).end()
#define sz(x) (int)x.size()

#define vi vector<int>
#define vii vector<ii>
#define pb push_back

#define ii pair<int,int>
#define fi first
#define se second
#define mp make_pair

#define ll long long

#define inf 1000000001
#define maxC 100003
#define maxD 102
#define maxK 102
#define maxn 103

int n, low[maxn], num[maxn], cnt;
bool visited[maxn], hasCycle;
vi g[maxn], topo, st;

void topoSort(int u)
{
    visited[u] = true;

    REP(i, sz(g[u])) {
        int v = g[u][i];

        if(!visited[v])
            topoSort(v);
    }
    topo.pb(u);
}

void tarjan(int u, int p)
{
    low[u] = num[u] = ++cnt;
    visited[u] = true;
    st.pb(u);

    REP(i, sz(g[u])) {
        int v = g[u][i];

        if(!num[v]) tarjan(v, u);
        if(visited[v]) low[u] = min(low[u], low[v]);
    }

    if(low[u] == num[u]) {
        int gg = 0;
        while(!st.empty()) {
            ++gg;
            int v = st.back();  st.pop_back(); visited[v] = false;
            if(v == u) break;
        }
        if(gg > 1) hasCycle = true;
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);     cout.tie(0);

    freopen("BACSI.INP", "r", stdin);
    freopen("BACSI.OUT", "w", stdout);

    cin >> n;
    FOR(i, 1, n) {
        int k;
        cin >> k;

        while(k--) {
            int u;
            cin >> u;
            g[u].pb(i);
        }
    }

    FOR(i, 1, n) visited[i] = false;
    FOR(i, 1, n)
        if(!num[i])
            tarjan(i, 0);

    if(hasCycle) {
        cout << "0\n";
        return 0;
    }

    FOR(i, 1, n) visited[i] = false;
    FORD(i, n, 1) if(!visited[i]) topoSort(i);

    reverse(ALL(topo));


    cout << "1\n";
    REP(i, sz(topo)) cout << topo[i] << '\n';
}
