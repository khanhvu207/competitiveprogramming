#include <iostream>
#include <stdio.h>
#include <queue>
#include <string.h>
#include <map>

using namespace std;

int n;

struct data {
    int length, id;
    data(int l, int i) {
        length = l; id = i;
    }
    bool operator < (data x) const {
        if (!length) return true;
        if (!x.length) return false;
        int k1, x1, k2, x2;
        if (id - length == 1) k1 = 1, x1 = 0;
        else if (id > n) k1 = n, x1 = length-1;
        else k1 = id-length+(length-1)/2, x1 = (length-1)/2;
        if (x.id - x.length == 1) k2 = 1, x2 = 0;
        else if (x.id > n) k2 = n, x2 = x.length-1;
        else k2 = x.id-x.length+(x.length-1)/2, x2 = (x.length-1)/2;
        return x1 < x2 || (x1 == x2 && k1 > k2);
    }
};

int main() {
    freopen("parking.inp", "r", stdin);
    freopen("parking.out", "w", stdout);
    int m;
    cin >> n >> m;
    int car[n+2], left[n+2], right[n+2];
    map <int, int> lab;
    left[n+1] = 0; right[0] = n+1;
    memset(car, 0, sizeof car);
    car[n+1] = n;
    priority_queue <data> heap;
    heap.push(data(n, n+1));
    while (m--) {
        int t, x, k, k1, k2;
        cin >> t >> x;
        if (t == 1) {
            do {
                k = heap.top().length, k1, k2 = heap.top().id;
                heap.pop();
            } while (k != car[k2]);
            if (k2 - k == 1) {
                k1 = 1;
                //car[k1] = 0;
                car[k2] = k-1;
                heap.push(data(0, 1));
                heap.push(data(k-1, k2));
            }
            else if (k2 > n) {
                k1 = k2-1;
                car[k1] = k-1;
                //car[k2] = 0;
                heap.push(data(k-1, k1));
                heap.push(data(0, k2));
            }
            else {
                k1 = k2-k+(k-1)/2;
                car[k1] = (k-1)/2;
                car[k2] = k-1-(k-1)/2;
                if ((k-1)/2) heap.push(data((k-1)/2, k1));
                if (k-1-(k-1)/2) heap.push(data(k-1-(k-1)/2, k2));
            }
            lab[x] = k1;
            right[k1] = k2;
            right[left[k2]] = k1;
            left[k1] = left[k2];
            left[k2] = k1;
            cout << k1 << '\n';
        }
        else {
            car[right[lab[x]]] += car[lab[x]]+1;
            left[right[lab[x]]] = left[lab[x]];
            right[left[lab[x]]] = right[lab[x]];
            car[lab[x]] = 0;
            heap.push(data(car[right[lab[x]]], right[lab[x]]));
        }
    }
    return 0;
}
