#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector <long long> point, cmpr, FT, Rank;

int get(int x) {
    x++;
    int res = 0;
    for (x = x; x < FT.size(); x += x & (-x))
        res += FT[x];
    return res;
}

void update(int x) {
    x++;
    for (x = x; x > 0; x -= x & (-x))
        FT[x]++;
}

int main() {
    freopen("ranking1.inp", "r", stdin);
    freopen("ranking1.out", "w", stdout);
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n, m; cin >> n >> m;
    point.resize(n);
    cmpr.resize(n);
    FT.resize(n + 1, 0);
    Rank.resize(n);
    for (int i = 0; i < n; i++)
        cin >> point[i], cmpr[i] = point[i];
    sort(cmpr.begin(), cmpr.end());
    for (int i = 0; i < n; i++) {
        int x = find(cmpr.begin(), cmpr.end(), point[i]) - cmpr.begin();
        Rank[i] = get(x) + 1;
        update(x);
    }
    while (m--) {
        int x; cin >> x;
        cout << Rank[x - 1] << '\n';
    }
}
