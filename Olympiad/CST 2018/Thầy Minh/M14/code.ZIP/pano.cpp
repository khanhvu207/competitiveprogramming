#include <iostream>
#include <stdio.h>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

#define ii pair <int, int>

struct data {
    int l, c, s;
} w[100];

bool cmp(data a, data b) {
    return a.s < b.s;
}

vector <int> f(20001, 0);

int main() {
    freopen("pano.inp", "r", stdin);
    freopen("pano.out", "w", stdout);
    int n, m; cin >> n >> m;
    for (int i = 0; i < m; i++)
        cin >> w[i].l >> w[i].c >> w[i].s;
    sort(w, w + m, cmp);
    for (int i = 0; i < m; i++) {
        priority_queue <ii> heap;
        for (int j = max(w[i].s - w[i].l + 1, 1); j <= w[i].s; j++)
            heap.push(ii(f[j - 1] + (w[i].s - j + 1) * w[i].c, w[i].s - j + 1));
        for (int j = w[i].s; j <= n; j++) {
            f[j] = max(f[j], f[j - 1]);
            while (!heap.empty() && heap.top().second + j - w[i].s > w[i].l) heap.pop();
            if (!heap.empty()) f[j] = max(f[j], heap.top().first + (j - w[i].s) * w[i].c);
        }
    }
    cout << f[n];
}
