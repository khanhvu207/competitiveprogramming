#include <iostream>
#include <cstdio>

#define ll long long
#define maxN 55

using namespace std;
ll F[maxN][maxN]; int n,k; ll K; string s;

int main()
{
    freopen("dict1.inp","r",stdin);
    freopen("dict1.out","w",stdout);
    F[1][0]=F[1][1]=1;
//    for (int i=0; i<=50; i++) F[0][i]=1e18;
    for (int i=2; i<=50; i++) F[i][0]=1;
    for (int i=2; i<=50; i++) for (int j=1; j<=50; j++) F[i][j]+=F[i-1][j]+F[i-1][j-1];
    while (scanf("%d%d%lld ",&n,&k,&K)==3)
    {
        getline(cin,s);
//        cout<<F[n][k]<<'\n';
        ll res=0;
        int kk=k;
        for (int i=0; i<s.length(); i++)
        {
            if (s[i]=='1')
            {
                res+=F[n-i-1][kk];
                kk--;
            }
        }
        printf("%lld ",res+1);
        string RES="";
        kk=k;
        for (int i=1; i<n; i++)
        {
            if (K>F[n-i][kk])
            {
                K-=F[n-i][kk];
                RES+='1';
                kk--;
            }
            else RES+='0';
        }
        if (kk>0) RES+='1'; else RES+='0';
        cout<<RES<<'\n';
    }
//    cout<<'\n'<<F[4][2]<<' '<<F[3][2]<<' '<<F[2][2];
//    cout<<F[2][2]<<' '<<F[1][1];
    return 0;
}
