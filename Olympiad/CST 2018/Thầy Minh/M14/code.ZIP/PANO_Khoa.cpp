#include <iostream>
#include <cstdio>
#include <algorithm>

#define ll long long

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,a) for(int i = 0; i < (a); i++)
#define REPD(i,a) for(int i = (a)-1; i >= 0; i--)
#define sz(a) (int)a.size()

using namespace std;

const int N = 2e4+5, M = 105;

struct data{int l, c, s; } a[M];

int n, m, L[M], C[M], S[M], f[M][N];

bool cmp(data a, data b) {return a.s < b.s;}

int main()
{
        freopen("PANO.INP","r",stdin);
        freopen("PANO.OUT","w",stdout);
    scanf("%d%d",&n,&m);
    FOR(i,1,m) scanf("%d%d%d",&a[i].l,&a[i].c,&a[i].s);
    sort(a+1,a+m+1,cmp);
    FOR(i,1,m)
    {
        L[i] = a[i].l;
        S[i] = a[i].s;
        C[i] = a[i].c;
    }
    FOR(i,1,m)
    {
        FOR(j,1,n)
        {
            f[i][j] = max(f[i-1][j], f[i][j-1]);
            if (S[i] <= j && j <= S[i]+L[i])
            {
                FOR(k,max(0,j-L[i]),S[i]-1)
                {
                    f[i][j] = max(f[i][j], f[i-1][k] + (j-k)*C[i]);
                }
            }
        }
    }

//    FOR(i,1,m) FOR(j,1,n) cout << f[i][j] << " \n"[j==n];

    cout << f[m][n];
    return 0;
}
