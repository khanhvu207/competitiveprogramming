#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
#define nmax 100010
typedef long long ll;

int n,tmp;
ll a[nmax], b[nmax], c[nmax], ans[nmax];
int bit[nmax];

void qs(int l, int r){
    int i = l, j = r, x = a[(int)(l+r)/2];
    do{
        while (a[i] < x) i++;
        while (x < a[j]) j--;
        if (!(i>j)){
            ll t = a[i]; a[i] = a[j]; a[j] = t;
            t = b[i]; b[i] = b[j]; b[j] = t;
            i++; j--;
        }
    }while (i <= j);
    if (l < j) qs(l,j);
    if (i < r) qs(i,r);
}

int get(int x){
    int re = 0;
    while (x < nmax)
    {
        re += bit[x];
        x += x & (-x);
    }
    return re;
}

void update(int x){
    while (x > 0)
    {
        bit[x] += 1;
        x -= x & (-x);
    }
}

int main()
{
    freopen("ranking2.inp","r",stdin);
    freopen("ranking2.out","w",stdout);

    cin >> n >> tmp;
    for (int i = 1; i <= n; i++) cin >> a[i], b[i] = i;
    qs(1,n);
    int m = 1; c[b[1]] = 1;
    for (int i = 2; i<=n; i++)
        if (a[i-1] != a[i]){
            m++;
            c[b[i]] = m;
        }

    for (int i = 1; i<=n; i++)
    {
        int p = get(c[i] + 1) + 1;
        ans[i] = p;
        update(c[i]);
    }

    while (tmp--){
        cin >> n;
        cout << ans[n] << "\n";
    }
    return 0;
}
