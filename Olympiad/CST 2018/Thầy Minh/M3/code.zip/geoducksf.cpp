#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;

int n,e,s,m,g,t, c[101][101], sa[101], ma[101];
bool oc[110];

int main()
{
    freopen("GEODUCKSF.INP","r",stdin);
    freopen("GEODUCKSF.OUT","w",stdout);

    cin >> n >> e >> s >> m >> g >> t;
    if (s == 0 || m == 0) { cout << "NO"; return 0; }
    for (int i = 0; i<e; i++)
    {
        int u,v,x;
        cin >> u >> v >> x;
        c[u][v] = c[v][u] = 2*x;
    }
    for (int i = 0; i<s; i++) cin >> sa[i];
    for (int i = 0; i<m; i++) cin >> ma[i];
    memset(oc,false,sizeof(oc));
    for (int i = 0; i<g; i++)
    {
        int x; cin >> x;
        oc[x] = true;
    }

    int x = 0, y = 0, tx = 0, ty = 0;
    for (int i = 0; i <= 2*t; i++)
    {
        if (oc[sa[x]] || oc[ma[y]]) break;
        if (sa[x] == ma[y] && !tx && !ty) {printf("YES\n%d %.1f", sa[x], (float)i/2); return 0;}
        if (sa[x] == ma[y+1] && sa[x+1] == ma[y] && tx + ty == c[sa[x]][ma[y]])
            {printf("YES\n%d %d %.1f", sa[x], ma[y], (float)i/2); return 0;}
        if (x == s-1 && y == m-1) break;
        if (x < s-1){
            tx++;
            if (tx == c[sa[x]][sa[x+1]]) {x++; tx = 0;}
        }
        if (y < m-1){
            ty++;
            if (ty == c[ma[y]][ma[y+1]]) {y++; ty = 0;}
        }
    }

    cout << "NO";
    return 0;
}
