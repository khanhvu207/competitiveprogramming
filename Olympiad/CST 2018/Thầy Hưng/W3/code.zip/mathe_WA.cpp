#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;

int main() {
    freopen("mathe.inp", "r", stdin);
    freopen("mathe.out", "w", stdout);
    long long n, d;
    cin >> n >> d;
    string PIN[n];
    for (int i = 0; i < n; i++)
        cin >> PIN[i];
    long long s[4];
    s[0] = s[1] = s[2] = 0;
    for (int c1 = 0; c1 < 4; c1++) {
        string str[n];
        for (int i = 0; i < n; i++)
            str[i] = PIN[i][c1];
        sort(str, str+n);
        long long cnt = 1;
        for (int i = 1; i < n; i++)
            if (str[i] > str[i-1]) s[0] += cnt*(cnt-1)/2, cnt = 1;
            else cnt++;
        s[0] += cnt*(cnt-1)/2;
        for (int c2 = c1+1; c2 < 4; c2++) {
            string str[n];
            for (int i = 0; i < n; i++)
                str[i] = PIN[i][c1] + PIN[i][c2];
            sort(str, str+n);
            long long cnt = 1;
            for (int i = 1; i < n; i++)
                if (str[i] > str[i-1]) s[1] += cnt*(cnt-1)/2, cnt = 1;
                else cnt++;
            s[1] += cnt*(cnt-1)/2;
            for (int c3 = c2+1; c3 < 4; c3++) {
                string str[n];
                for (int i = 0; i < n; i++)
                    str[i] = PIN[i][c1] + PIN[i][c2] + PIN[i][c3];
                sort(str, str+n);
                long long cnt = 1;
                for (int i = 1; i < n; i++)
                    if (str[i] > str[i-1]) s[2] += cnt*(cnt-1)/2, cnt = 1;
                    else cnt++;
                s[2] += cnt*(cnt-1)/2;
            }
        }
    }
    sort(PIN, PIN+n);
    long long cnt = 1;
    s[3] = 0;
    for (int i = 1; i < n; i++)
        if (PIN[i] > PIN[i-1]) s[3] += cnt*(cnt-1)/2, cnt = 1;
        else cnt++;
    s[3] += cnt*(cnt-1)/2;
    if (d == 1) cout << s[2] - 4*s[3];
    else if (d == 2) cout << s[1] - 3*s[2] + 12*s[3];
    else if (d == 3) cout << s[0] - 2*s[1] + 3*s[2] - 4*s[3];
    else cout << n*(n-1)/2 - s[0] + s[1] - s[2] - 4*s[3];
}
