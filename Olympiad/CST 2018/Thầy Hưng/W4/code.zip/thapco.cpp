#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <vector>

using namespace std;

int main(){
    freopen("thapco.inp","r",stdin);
    freopen("thapco.out","w",stdout);

    long long n,d;
    cin >> n >> d;
    vector<long long> v;
    for (int i = 1; i<=n; i++){
        int x; cin >> x;
        v.push_back(x);
    }
    sort(v.begin(),v.end());

    long long ans = 1;
    for (int lo=0, hi=1; hi<n; ++hi){
        while (v[hi]-v[lo] > d) ++lo;
        ans = (ans * (hi-lo+1)) % 1000000009;
    }

    cout << ans;
    return 0;
}
