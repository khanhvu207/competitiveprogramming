// Nguyen Cao Nhat Long
// Pikachuuuuuuuuuuuuu
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <set>
#include <queue>
#include <vector>
#include <stack>
#include <map>
#include <string>
#include <sstream>
using namespace std;

#define next oapsidfjiuunfiujfa
#define prev sdofljkauohfaodisf

#define sqr(x) ((x)*(x))
#define PI acos(-1)

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,a) for(int i = 0, _a = (a); i < _a; i++)
#define REPD(i,n) for(int i = (n) - 1; i >= 0; i--)

#define ii pair<int,int>
#define fi first
#define se second
#define mp make_pair

#define sz(x) (int)x.size()
#define ALL(x) (x).begin(), (x).end()
#define MS(a,x) memset(a, x, sizeof(a))

#define sync ios::sync_with_stdio(false)
#define ll long long

#define vi vector<int>
#define vll vector<ll>
#define vii vector<ii>
#define pb push_back

#define inf 1000000000
#define INF 100000000000000000LL
#define mod 1000000007LL
#define maxn 20003
#define maxm 102

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);     cout.tie(0);

    freopen("TRAIL.INP", "r", stdin);
    freopen("TRAIL.OUT", "w", stdout);

    int k;
    cin >> k;

    int id = 0, n = 0, m = 0;
    vector<vi> res;

    while(k) {
        vi tmp;
        int l = 1, r = 5000, mid, save = 1;

        while(l <= r) {
            mid = (l + r) >> 1;

            if(mid*(mid - 1)/2 <= k) {
                save = mid;
                l = mid + 1;
            }
            else r = mid - 1;
        }

        FOR(i, id + 1, id + save) tmp.pb(i);
        id += save;
        res.pb(tmp);
        m += save - 1;
        n += save;
        k -= save*(save - 1) / 2;
    }

    cout << n << ' ' << m << '\n';
    REP(i, sz(res)) {
        REP(j, sz(res[i]) - 1) {
            cout << res[i][j] << ' ' << res[i][j + 1] << '\n';
        }
        cout << res[i].back() << ' ' << res[i][0] << '\n';
    }
}
