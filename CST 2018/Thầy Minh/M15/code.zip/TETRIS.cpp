/*
	Nhandeptrai
*/
#include <iostream>
#include <cstdio>
#include <cstring>

#define ll long long

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,a) for(int i = 0; i < (a); i++)
#define REPD(i,a) for(int i = (a)-1; i >= 0; i--)
#define sz(a) (int)a.size()

using namespace std;

const int N = 255;

int n, cnt, a[N], b[N];
ll pow[N][6], f[N][N][N];

void calcPow()
{
    FOR(i,1,250)
    {
        pow[i][0] = 1;
        FOR(j,1,5) pow[i][j] = 1LL*pow[i][j-1]*i;
    }
}

void zip()
{
    cnt = 1; b[1] = 1;
    FOR(i,2,n)
    {
        if (a[i] != a[cnt])
        {
            ++cnt;
            a[cnt] = a[i];
            b[cnt] = 1;
        } else b[cnt]++;
    }
}

ll calc(int l, int r, int k)
{
    if (l > r) return 0;
    if (l == r) return pow[b[l]+k][a[l]];
    if (f[l][r][k] != -1) return f[l][r][k];

    f[l][r][k] = calc(l,r-1,0) + calc(r,r,k);
    FOR(i,l,r-1)
    {
        if (a[i] == a[r])
        {
            f[l][r][k] = max(f[l][r][k], calc(i+1,r-1,0) + calc(l,i,b[r]+k));
        }
    }
    return f[l][r][k];
}

int main()
{
        freopen("TETRIS.INP","r",stdin);
        freopen("TETRIS.OUT","w",stdout);
    calcPow();
    while (scanf("%d",&n) == 1)
    {
        FOR(i,1,n) scanf("%d",&a[i]);
        zip();

//        FOR(i,1,cnt) cout << a[i] << " " << b[i] << "\n";
//        return 0;

        memset(f,-1,sizeof(f));
        printf("%lld\n",calc(1,cnt,0));
    }
    return 0;
}
