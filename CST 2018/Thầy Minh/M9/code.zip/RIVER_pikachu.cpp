// Nguyen Cao Nhat Long
// Pikachuuuuuuuuuuuuu
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <set>
#include <queue>
#include <vector>
#include <stack>
#include <map>
#include <string>
#include <sstream>
using namespace std;

#define next oapsidfjiuunfiujfa
#define prev sdofljkauohfaodisf

#define sqr(x) ((x)*(x))
#define PI acos(-1)

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,a) for(int i = 0, _a = (a); i < _a; i++)
#define REPD(i,n) for(int i = (n) - 1; i >= 0; i--)

#define ii pair<int,int>
#define fi first
#define se second
#define mp make_pair

#define sz(x) (int)x.size()
#define ALL(x) (x).begin(), (x).end()
#define MS(a,x) memset(a, x, sizeof(a))

#define sync ios::sync_with_stdio(false)

#define vi vector<int>
#define vll vector<ll>
#define vii vector<ii>
#define pb push_back

#define inf 1000000000
#define INF 100000000000000000LL
#define mod 1000000007LL
#define maxn 1003

#define iii pair<int,ii>

int n, d[maxn][5*maxn], a[maxn], b[maxn];

bool available(int id, int t)
{
    if(id == 0 || id == n + 1) return true;

    t = (t % (a[id] + b[id]));
    return t >= 1 && t <= a[id];
}

void Dijkstra()
{
    FOR(i, 0, n + 1) FOR(j, 0, 10000) d[i][j] = false;
    d[0][0] = true;

    queue<ii> q;    q.push(ii(0,0));

    while(!q.empty())
    {
        ii u = q.front();   q.pop();
        if(u.se > 5000) continue;

        if(u.fi == n + 1) {
            cout << u.se << '\n';
            return;
        }

        FOR(v, max(0, u.fi - 5), min(u.fi + 5, n + 1)) {

            if(available(v, u.se + 1) && !d[v][u.se + 1]) {
                d[v][u.se + 1] = true;
                q.push(ii(v, u.se + 1));
            }
        }
    }

    cout << "NO\n";
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);     cout.tie(0);

    freopen("RIVER.INP", "r", stdin);
    freopen("RIVER.OUT", "w", stdout);

    int nTest;
    cin >> nTest;

    while(nTest--)
    {
        cin >> n;
        FOR(i, 1, n) cin >> a[i] >> b[i];

        a[0] = a[n + 1] = 1;
        Dijkstra();
    }
}
