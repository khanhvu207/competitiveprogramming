#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
#define ii pair<int,int>
#define iii pair<int,ii>
#define fi first
#define se second

int n, a[1010], b[1010], d[1010][10000];

bool check(int v, int time){
    if (v == 0 || v == n+1) return true;
    time %= (a[v] + b[v]);
    return (1 <=  time && time <= a[v]);
}

int main()
{
    freopen("RIVER.inp","r",stdin);
    freopen("RIVER.OUT","w",stdout);

int t; cin >> t;
while (t--)
{
    cin >> n;
    for (int i = 1; i<=n; i++) scanf("%d%d", &a[i], &b[i]);
    a[0] = a[n+1] = 1;

    for (int i = 0; i<=n+1; i++)
        for (int j = 0; j<=10000; j++) d[i][j] = false;
    d[0][0] = true;

    bool kt = false;
    queue<ii> q; q.push(ii(0,0));
    while (!q.empty())
    {
        ii tmp = q.front(); q.pop();
        if (tmp.se > 5000) continue;
        if (tmp.fi == n+1)
        {
            kt = true;
            printf("%d\n", tmp.se);
            break;
        }

        int u = tmp.fi, time = tmp.se;
        for (int v = max(u-5,0); v <= min(u+5,n+1); v++)
            if (check(v,time+1) && !d[v][time+1])
            {
                d[v][time+1] = true;
                q.push(ii(v,time+1));
            }

    }
    if (!kt) printf("NO\n");
}

    return 0;
}
