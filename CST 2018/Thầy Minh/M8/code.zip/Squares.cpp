#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;

bool Equal(double x, double y) {return max(x - y, y - x) <= 1e-12;}

bool Less_or_Equal(double x, double y) {return Equal(x, y) || x < y;}

double sqr(double x) {return x*x;}

double intersect(double x, double y, double x1, double y1, double x2, double y2) {
    double res = 1e9;
    if (!Equal(x, 0) && Less_or_Equal(0, x*x1) && Less_or_Equal(y1, double((y*x1)/x)) && Less_or_Equal(double((y*x1)/x), y2)) res = min(res, sqr((y*x1)/x)+sqr(x1));
    if (!Equal(x, 0) && Less_or_Equal(0, x*x2) && Less_or_Equal(y1, double((y*x2)/x)) && Less_or_Equal(double((y*x2)/x), y2)) res = min(res, sqr((y*x2)/x)+sqr(x2));
    if (!Equal(y, 0) && Less_or_Equal(0, y*y1) && Less_or_Equal(x1, double((x*y1)/y)) && Less_or_Equal(double((x*y1)/y), x2)) res = min(res, sqr((x*y1)/y)+sqr(y1));
    if (!Equal(y, 0) && Less_or_Equal(0, y*y2) && Less_or_Equal(x1, double((x*y2)/y)) && Less_or_Equal(double((x*y2)/y), x2)) res = min(res, sqr((x*y2)/y)+sqr(y2));
    return res;
}

int main() {
    //freopen("squares.inp", "r", stdin);
    //freopen("squares.out", "w", stdout);
    int n;
    cin >> n;
    double x1[n], y1[n], x2[n], y2[n], x[4*n], y[4*n];
    for (int i = 0; i < n; i++) {
        double l;
        cin >> x1[i] >> y1[i] >> l;
        x2[i] = x1[i]+l; y2[i] = y1[i]+l;
        x[i*4+0] = x1[i]; y[i*4+0] = y1[i];
        x[i*4+1] = x1[i]; y[i*4+1] = y2[i];
        x[i*4+2] = x2[i]; y[i*4+2] = y1[i];
        x[i*4+3] = x2[i]; y[i*4+3] = y2[i];
    }
    bool seen[n];
    memset(seen, false, sizeof seen);
    for (int i = 0; i < 4*n-1; i++)
        for (int j = i+1; j < 4*n; j++) {
            int ind = -1; double m = 1e9;
            for (int k = 0; k < n; k++) {
                double tmp = intersect((x[i]+x[j])/2, (y[i]+y[j])/2, x1[k], y1[k], x2[k], y2[k]);
                if (!(Less_or_Equal(m, tmp))) m = tmp, ind = k;
            }
            if (ind >= -1) seen[ind] = true;
        }
    int cnt = 0;
    for (int i = 0; i < n; i++)
        cnt += seen[i];
    cout << cnt;
    return 0;
}