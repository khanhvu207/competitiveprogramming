// Nguyen Cao Nhat Long
// Pikachuuuuuuuuuuuuu
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <set>
#include <queue>
#include <vector>
#include <stack>
#include <map>
#include <string>
#include <sstream>
using namespace std;

#define next oapsidfjiuunfiujfa
#define prev sdofljkauohfaodisf

#define sqr(x) ((x)*(x))
#define PI acos(-1)

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,a) for(int i = 0, _a = (a); i < _a; i++)
#define REPD(i,n) for(int i = (n) - 1; i >= 0; i--)

#define ii pair<int,int>
#define fi first
#define se second
#define mp make_pair

#define sz(x) (int)x.size()
#define ALL(x) (x).begin(), (x).end()
#define MS(a,x) memset(a, x, sizeof(a))

#define sync ios::sync_with_stdio(false)

#define vi vector<int>
#define vll vector<ll>
#define vii vector<ii>
#define pb push_back

#define inf 1000000000
#define INF 100000000000000000LL
#define mod 1000000007LL
#define maxn 1003

#define EPS 1e-10

int cmp(double a, double b) { return a < b - EPS ? -1 : (a > b + EPS ? 1 : 0); }

struct POINT
{
    double x, y;

    POINT() { x = y = 0; }
    POINT(double X, double Y): x(X), y(Y) {}

    POINT operator +(const POINT& p) { return POINT(x + p.x, y + p.y); }
    POINT operator -(const POINT& p) { return POINT(x - p.x, y - p.y); }
    POINT operator *(double k) { return POINT(k*x, k*y); }
    POINT operator /(double k) { return POINT(x/k, y/k); }

    double operator *(const POINT& p) { return x*p.x + y*p.y; } // dot product
    double operator %(const POINT& p) { return x*p.y - y*p.x; } // cross product
    /*
        | x   y |
        |p.x p.y|
    */

    double norm() { return x*x + y*y; }
    double len() { return hypot(x, y); } // hypot is slower but more accurate
};

int cmp(POINT a, POINT b) {
    return cmp(a.x, b.x) == -1 ? -1 : (cmp(a.x, b.x) == 1 ? 1 : cmp(a.y, b.y));
}

struct LINE
{
    double a, b, c;
    POINT A, B;

    LINE() { a = b = c = 0; }
    LINE(double a, double b, double c): a(a), b(b), c(c) {}
    LINE(POINT A, POINT B): A(A), B(B) {
        a = A.y - B.y;
        b = B.x - A.x;
        c = B.y*A.x - B.x*A.y;
    }
    double f(POINT p) { return a*p.x + b*p.y + c; }
};

POINT intersect(LINE l1, LINE l2)
{
    l1.c = -l1.c;       l2.c = -l2.c;

    double d = l1.a * l2.b - l2.a * l1.b;
    double dx = l1.c * l2.b - l2.c * l1.b;
    double dy = l1.a * l2.c - l2.a * l1.c;

    return POINT(dx/d, dy/d);
}

POINT closestPoint(POINT p, LINE l)
{
    POINT ans;

    if(!cmp(l.a, 0)) {
        ans.x = p.x;    ans.y = -l.c / l.b;
        return ans;
    }
    if(!cmp(l.b, 0)) {
        ans.y = p.y;    ans.x = -l.c / l.a;
    }

    LINE perp(-l.b, l.a, l.b*p.x - l.a*p.y);
    return intersect(perp, l);
}

POINT reflect(POINT p, LINE l)
{
    POINT x = closestPoint(p, l);
    return x*2 - p;
}

struct BOX
{
    LINE u, d, l, r;
    BOX() {}
    BOX(double x, double y, double w, double h) {
        POINT ll(x,y);
        POINT ur(x + w, y + h);

        u = LINE(POINT(ll.x, ur.y), ur);
        d = LINE(ll, POINT(ur.x, ll.y));
        l = LINE(ll, POINT(ll.x, ur.y));
        r = LINE(ur, POINT(ur.x, ll.y));
    }
} box[maxn];

int N;
POINT cur(0,0), dir(0,0);
bool fucked[maxn];

bool doesCut(LINE l, LINE l2) {
    return cmp(l.f(l2.A) * l.f(l2.B), 0) <= 0;
}

bool rampage(LINE& res, int& id)
{
    POINT p = POINT(1e4, 1e4);
    bool ok = false;
    LINE l(cur, dir);

    FOR(i, 1, N) if(!fucked[i]) {
        if(doesCut(l, box[i].u)) {
            ok = true;
            POINT c = intersect(l, box[i].u);
            if(cmp((c - cur).len(), (p - cur).len()) < 0)
                p = c, res = box[i].u, id = i;
        }
        if(doesCut(l, box[i].d)) {
            ok = true;
            POINT c = intersect(l, box[i].d);
            if(cmp((c - cur).len(), (p - cur).len()) < 0)
                p = c, res = box[i].d, id = i;
        }
        if(doesCut(l, box[i].l)) {
            ok = true;
            POINT c = intersect(l, box[i].l);
            if(cmp((c - cur).len(), (p - cur).len()) < 0)
                p = c, res = box[i].l, id = i;
        }
        if(doesCut(l, box[i].r)) {
            ok = true;
            POINT c = intersect(l, box[i].r);
            if(cmp((c - cur).len(), (p - cur).len()) < 0)
                p = c, res = box[i].r, id = i;
        }
    }

    return ok;
}

void process()
{
    LINE l;
    int id;

    while(rampage(l, id))
    {
        fucked[id] = true;
        POINT p = intersect(l, LINE(cur, dir));

        double ty = (dir - cur).y;
        double tx = (dir - cur).x;
        if(cmp(fabs(ty), fabs(tx)) == 0) {
            if((tx >= 0 && ty >= 0 && cmp(p, intersect(box[id].l, box[id].d)) == 0) ||
               (tx <= 0 && ty >= 0 && cmp(p, intersect(box[id].r, box[id].d)) == 0) ||
               (tx <= 0 && ty <= 0 && cmp(p, intersect(box[id].u, box[id].r)) == 0) ||
               (tx >= 0 && ty <= 0 && cmp(p, intersect(box[id].u, box[id].l)) == 0))
            {
                dir = cur;
                cur = p;
                cout << id << '\n';
                continue;
            }
        }

        LINE perp(-l.b, l.a, l.b*p.x - l.a*p.y);
        dir = reflect(cur, perp);
        cur = p;
        cout << id << '\n';
    }
}

int main()
{
    freopen("BOXES.INP", "r", stdin);
    freopen("BOXES.OUT", "w", stdout);

    ios::sync_with_stdio(false);
    cin.tie(0);     cout.tie(0);

    cin >> N;
    cin >> dir.x >> dir.y;
    FOR(i, 1, N) {
        double x, y, w, h;
        cin >> x >> y >> w >> h;
        box[i] = BOX(x, y, w, h);
    }

    process();
}
/*
3
1 -1
1 0 90 20
1 -22 90 20
1 -44  90 20
*/
