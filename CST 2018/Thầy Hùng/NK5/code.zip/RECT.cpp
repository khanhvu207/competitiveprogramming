/*
	47/50
*/
#include <iostream>
#include <cstdio>

#define FOR(i,a,b) for (int i = (a); i <= (b); i++)

using namespace std;

const int maxn = 1005;
int n,cnt;
bool visit[maxn],A[maxn][maxn];
struct point
{
    int x,y;
    point() {}
    point(int a,int b) {x = a; y = b;}
};
struct rec {point p[4];} a[maxn];

int ccw(point a,point b,point c)
{
    float dx1 = b.x - a.x,dy1 = b.y - a.y,
        dx2 = c.x - a.x,dy2 = c.y - a.y;
    float d = dx1 * dy2 - dx2 * dy1;
    if (d < 0) return -1; else
    if (d > 0) return 1; else
    if (dx1 * dx2 < 0 || dy1 * dy2 < 0) return -1; else
    if (dx1 * dx1 + dy1 * dy1 >= dx2 * dx2 + dy2 * dy2) return 0; else return -1;
}

bool inside(point A,rec a)
{
    FOR(i,0,3)
    {
        int cnt = 0;
        point B = a.p[i];
        FOR(j,0,3)
        {
            point C = a.p[j],
                  D = a.p[(j + 1) % 4];
            if (ccw(A,B,C) * ccw(A,B,D) <= 0 && ccw(C,D,A) * ccw(C,D,B) <= 0) cnt++;
        }
        if (cnt != 2) return false;
    }
    return true;
}

bool cut(rec a,rec b)
{
    FOR(i,0,3) if (inside(a.p[i],b)) return true;
    FOR(i,0,3)
    {
        point A = a.p[i],
              B = a.p[(i + 1) % 4];
        FOR(j,0,3)
        {
            point C = b.p[j],
                  D = b.p[(j + 1) % 4];
            if (ccw(A,B,C) * ccw(A,B,D) <= 0 && ccw(C,D,A) * ccw(C,D,B) <= 0) return true;
        }
    }
    return false;
}

void DFS(int u)
{
    if (visit[u]) return;
    cnt++;
    visit[u] = true;
    FOR(v,1,n) if (A[u][v]) DFS(v);
}

int main()
{
    freopen("RECT.INP","r",stdin);
    freopen("RECT.OUT","w",stdout);
    scanf("%d",&n);
    FOR(i,1,n) FOR(j,0,3) scanf("%d%d",&a[i].p[j].x,&a[i].p[j].y);
    FOR(i,1,n) FOR(j,i + 1,n) if (cut(a[i],a[j]))
    {
        A[i][j] = true;
        A[j][i] = true;
    }
    int res = 0;
    FOR(i,1,n) if (!visit[i])
    {
        cnt = 0;
        DFS(i);
        res = max(res,cnt);
    }
    printf("%d",res);
    return 0;
}
