#include <iostream>
#include <math.h>
#include <stdio.h>
#include <algorithm>
#include <string.h>

using namespace std;

int a[4],b[3];
bool k[53];

void th1()
{
    int start = 53;
    if (a[3] < b[1]) start = 1;
    else if (a[2] < b[1]) start = a[2] + 1;
    else if (a[2] > b[1]) start = a[3] + 1;

    int x = -1;
    for (int i = start; i<=52; i++)
        if (k[i])
        {
            x = i; break;
        }
    cout << x << endl;
}

void th2()
{
    int start = 53;
    if (a[2] < b[1]) start = a[2] + 1;

    int x = -1;
    for (int i = start; i<=52; i++)
        if (k[i])
        {
            x = i; break;
        }
    cout << x << endl;
}

int main()
{
    freopen("12247.INP","r",stdin);
    freopen("12247.OUT","w",stdout);

    do{
        memset(k,true,sizeof(k));
        for (int i = 1; i<=3; i++)
        {
            int x; cin >> x;
            a[i] = x;
            k[x] = false;
            if (x == 0) return 0;
        }
        for (int i = 1; i<=2; i++)
        {
            int x; cin >> x;
            b[i] = x;
            k[x] = false;
        }
        sort(a+1,a+4); sort(b+1,b+3);

        if (a[3] < b[2]) th1();
        else if (a[3] > b[2])
                if (a[2] < b[2]) th2();
                else cout << -1 << endl;
    }while (1);

    return 0;
}
