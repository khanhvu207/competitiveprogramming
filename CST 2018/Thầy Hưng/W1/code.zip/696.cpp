#include <iostream>
#include <math.h>
#include <stdio.h>
#include <algorithm>
#include <string.h>

using namespace std;

int main()
{
    freopen("696.INP","r",stdin);
    freopen("696.OUT","w",stdout);

    int m,n,a,b;
    while (1)
    {
        cin >> a >> b;
        n = a; m = b;
        if (m == 0) return 0;

        int ans = 0;
        if (m > n) { int t = m; m = n; n = t; }
        if (m == 1) ans = n;
        else if (m == 2) ans = 4 * ( (int)n/4 ) + 2 * min(n % 4 , 2);
        else ans = (long long) ((m+1)/2)*((n+1)/2) + (m/2)*(n/2);
        cout << ans << " knights may be placed on a " << a << " row " << b << " column board." << endl;
    }

    return 0;
}
