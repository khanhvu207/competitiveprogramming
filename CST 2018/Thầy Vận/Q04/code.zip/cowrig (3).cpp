#include <fstream>

std::ifstream fin("cowrig.inp");
std::ofstream fout("cowrig.out");

const int dr[4] = {-1,0,1,0},
          dc[4] = {0,-1,0,1};
int a[5][5], b[5][5], p[25];

void input () {
    for (int i=0;i<5;i++) for (int j=0;j<5;j++) {
        char ch;
        fin >> ch;
        a[i][j] = (ch=='J') ? 1 : 0;
        p[i*5+j] = a[i][j];
    }
}
bool SevenOn (int mask) {
    int ans = 0;
    while (mask) {
        if (mask&1) ans++;
        mask>>=1;
    }
    return ans==7;
}
bool inside (int r,int c) {return r>=0 && r<5 && c>=0 && c<5;}
void floodfill (int a[][5], int r,int c, int c1, int c2) {
    a[r][c] = c2;
    for (int i=0;i<4;i++)
        if (inside(r+dr[i], c+dc[i]) && a[r+dr[i]][c+dc[i]]==c1)
            floodfill(a, r+dr[i], c+dc[i], c1, c2);
}
bool LienNhau (int mask) {
    for (int i=0;i<25;i++) b[i/5][i%5] = (mask&(1<<i)) ? 1 : 0;
    int ans = 0;
    for (int i=0;i<5;i++) for (int j=0;j<5;j++)
    if (b[i][j]) {ans++; floodfill(b,i,j,1,0);}
    return ans==1;
}
int NumOfArea () {
    int ans = 0;
    for (int mask=0;mask<(1<<25);mask++){
    if (SevenOn(mask) && LienNhau(mask)) {
        int sum=0;
        for (int i=0;i<25;i++) if (mask&(1<<i)) sum+=p[i];
        if (sum>=4) ans++;
    }
    }
    return ans;
}

int main() {
    input ();
    int ans = NumOfArea();
    fout << ans;
    return 0;
}
