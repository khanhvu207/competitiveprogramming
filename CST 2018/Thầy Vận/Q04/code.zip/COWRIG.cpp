/**
    Nguyen Cao Nhat Long - 11
**/
#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <cstdio>
#include <queue>
#include <iomanip>
#include <stack>
#include <queue>
#include <cstring>
#include <string>
#include <cmath>

using namespace std;

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,n) for(int i = 0; i < n; i++)
#define REPD(i,n) for(int i = n - 1; i >= 0; i--)

#define ALL(x) (x).begin(), (x).end()
#define sz(x) (int)x.size()

#define vi vector<int>
#define vii vector<ii>
#define pb push_back

#define ii pair<int,int>
#define fi first
#define se second
#define mp make_pair

#define ll long long

#define inf 1000000001
#define maxC 100003
#define maxD 102
#define maxK 102
#define maxn 103

int n = 5, m = 5, cnt, Jersey;
bool g[7][7], visited[7][7];
ii DIR[] = { ii(0,1), ii(-1,0), ii(0,-1) };
vii path;

bool checkRegion(ii u)
{
    bool valid = false;

    REP(k, sz(path)) {
        bool ok = false;

        REP(t, 3) {
            int x = u.fi + DIR[t].fi;
            int y = u.se + DIR[t].se;
            if(path[k] == ii(x,y))
                ok = true;
        }
        if(ok) valid = true;
    }

    return valid;
}

void Try(int id, ii root)
{
    if(id == 7) {
        if(Jersey > 3) cnt++;
        /*
        cout << Jersey << ": ";
        REP(i, sz(path)) cout << '(' << path[i].fi << ',' << path[i].se << ") ";
        cout << '\n';
        */
        return;
    }

    FOR(i, root.fi, n) FOR(j, 1, m) {
        if(i == root.fi && j < root.se)
            continue;
        if(visited[i][j]) continue;
        if(!checkRegion(ii(i,j))) continue;

        visited[i][j] = true;
        path.pb(ii(i,j));
        if(g[i][j]) Jersey++;

        if(Jersey + 7 - (id + 1) > 3)
            Try(id + 1, ii(i,j));

        if(g[i][j]) Jersey--;
        path.pop_back();
        visited[i][j] = false;
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);     cout.tie(0);

    freopen("COWRIG.INP", "r", stdin);
    freopen("COWRIG.OUT", "w", stdout);

    FOR(i, 1, n) FOR(j, 1, m) {
        char c;
        cin >> c;
        if(c == 'J') g[i][j] = true;
    }

    FOR(i, 1, n) FOR(j, 1, m) {
        if(g[i][j]) Jersey++;
        visited[i][j] = true;
        path.pb(ii(i,j));

        Try(1, ii(i,j));

        path.pop_back();
        visited[i][j] = false;
        if(g[i][j]) Jersey--;
    }

    cout << cnt << '\n';
}
