#include <iostream>
#include <cstdio>
using namespace std;
#define ll long long

char s[45];
int a[45], n;

int main(){
    freopen("pinary.inp","r",stdin);
    freopen("pinary.out","w",stdout);

    a[0] = 1; a[1] = 2; a[41] = 0;
    for (int i = 2; i<=40; i++) a[i] = a[i-1] + a[i-2];

    scanf("%d", &n);
    int k = lower_bound(a , a+41, n) - a;

    while (n != 0)
        if (a[k] == n)
        {
            cout << "1";
            for (int i = 1; i <= k; i++) cout << "0";
            break;
        } else
        {
            cout << "1";
            int K = k-1;
            n -= a[k-1];
            k = lower_bound(a , a+41, n) - a;
            if (a[k]==n) for (int i = K; i > k+1; i--) cout << "0";
            else for (int i = K; i > k; i--) cout << "0";
        }

    return 0;
}
