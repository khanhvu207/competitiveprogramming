#include <iostream>
#include <stdio.h>
#include <queue>

using namespace std;

#define ii pair <int, int>
#define iii pair <ii, int>

int x[250000];
ii f[250000];

int main() {
    freopen("stacker.inp", "r", stdin);
    freopen("stacker.out", "w", stdout);
    int n, m; cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        int xx; cin >> xx;
        x[i] = x[i - 1] + xx;
    }
    priority_queue <iii> heap; heap.push(iii(ii(0, 0), 0));
    for (int i = 1; i <= n; i++) {
        while (i - heap.top().second > m) heap.pop();
        f[i].first = heap.top().first.first + x[i];
        f[i].second = heap.top().first.second;
        heap.push(iii(ii(f[i].second - x[i], f[i].first), i));
    }
    cout << f[n].first;
}
