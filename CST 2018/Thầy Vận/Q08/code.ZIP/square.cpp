#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;

int f[50][50];

int split(int m, int n) {
    if (m > n) return split(n, m);
    if (f[m][n] > -1) return f[m][n];
    if (m == n) {
        f[m][n] = 1; return 1;
    }
    f[m][n] = 1e9;
    for (int i = 1; i < m; i++)
        f[m][n] = min(f[m][n], split(i, n) + split(m - i, n));
    for (int i = 1; i < n; i++)
        f[m][n] = min(f[m][n], split(m, i) + split(m, n - i));
    return f[m][n];
}

int main() {
    freopen("square.inp", "r", stdin);
    freopen("square.out", "w", stdout);
    int m, n; cin >> m >> n;
    memset(f, -1, sizeof f); cout << split(m, n);
}
