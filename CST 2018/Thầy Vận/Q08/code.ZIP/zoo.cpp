#include <iostream>
#include <cstdio>
using namespace std;
#define ll long long

ll a[100005], ans, n, s;

ll c2(ll x){return x*(x-1)/2;}
ll c3(ll x){return x*(x-1)*(x-2)/6;}

int main(){
    freopen("zoo.inp","r",stdin);
    freopen("zoo.out","w",stdout);

    scanf("%lld", &n);
    for (int i = 1; i <= n; i++) scanf("%lld", &a[i]), s += a[i];

    ans = c3(s);
    for (int i = 1; i <= n; i++) ans -= c2(a[i])*(s-a[i]) + c3(a[i]);

    printf("%lld", ans);
    return 0;
}
