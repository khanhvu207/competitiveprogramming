#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;
#define fi first
#define se second

int v, e, s, m, g, t, len[115][115], tm=1;
bool gd[115], flag;
vector<int> routea, routeb;

bool cmp (pair<pair<int, int>, int> l, pair<pair<int, int>, int> r)
{
    int al=l.fi.fi;
    int ar=l.fi.se;
    int bl=r.fi.fi;
    int br=r.fi.se;
    if (al>ar) swap(al, ar);
    if (bl>br) swap(bl, br);
    if (!(al==bl&&ar==br)) return false;
    if (l.fi.fi==r.fi.fi&&l.fi.se==r.fi.se&&l.se==r.se) return true;
    else
    {
        if (l.se+r.se==len[al][ar]) return true;
        else if (l.se+r.se+1==len[al][ar]&&tm+1<=t)
        {
            flag=1;
            return true;
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    freopen("geoducksf.inp", "r", stdin);
    freopen("geoducksf.out", "w", stdout);
    cin >> v >> e >> s >> m >> g >> t;
    for (int i=0, u, v, c; i<e; i++)
        cin >> u >> v >> c,
        len[u][v]=c, len[v][u]=c;
    for (int i=0, x; i<s; i++)
        cin >> x, routea.push_back(x);
    for (int i=0, x; i<m; i++)
        cin >> x, routeb.push_back(x);
    for (int i=1; i<=v; i++)
        gd[i]=0;
    for (int i=0, x; i<g; i++)
        cin >> x, gd[x]=1;

    if (t<1)
    {
        if (routea[0]==routeb[0]&&!gd[routea[0]])
            cout << "YES";
        else
            cout << "NO";
        return 0;
    }

    int cura=0, curb=0;
    routea.push_back(-1);
    routeb.push_back(-1);
    pair<pair<int, int>, int> la=make_pair(make_pair(routea[0], routea[1]), 1);
    pair<pair<int, int>, int> lb=make_pair(make_pair(routeb[0], routeb[1]), 1);
    while (tm+1<=t)
    {
        ++tm;
        if (la.fi.se!=-1) ++la.se;
        if (la.fi.se!=-1&&len[la.fi.fi][la.fi.se]<la.se)
        {
            lb.fi.fi=routea[cura+1];
            lb.fi.se=routea[cura+2];
            lb.se=1;
            ++cura;
        }

        if (lb.fi.se!=-1) ++lb.se;
        if (lb.fi.se!=-1&&len[lb.fi.fi][lb.fi.se]<lb.se)
        {
            lb.fi.fi=routeb[curb+1];
            lb.fi.se=routeb[curb+2];
            lb.se=1;
            ++curb;
        }

        if (la.se==1&&gd[routea[cura]])
        {
            cout << "NO";
            return 0;
        }
        if (lb.se==1&&gd[routeb[curb]])
        {
            cout << "NO";
            return 0;
        }
        flag=0;
        if (cmp(la, lb))
        {
            cout << "YES\n";
            if (la.se==1)
                cout << la.fi.fi << ' ' << tm << '\n';
            else
            {
                if (la.fi.fi>la.fi.se) swap(la.fi.fi, la.fi.se);
                cout << la.fi.fi << ' ' << la.fi.se << ' ' << tm << (flag?".5":"\n");
            }
            return 0;
        }
    }
    cout << "NO";
    return 0;
}

