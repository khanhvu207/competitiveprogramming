#include <iostream>
#include <stdio.h>
#include <math.h>
#include <sstream>
#include <queue>
#include <map>

#define oo 1000000000
using namespace std;

map<string,bool> p;
struct sty{
    int x,y,bac;
    sty(int a, int b, int c) { x = a; y = b; bac = c;}
};

string doi(int a, int b){
    stringstream s; s << a;
    stringstream x; x << b;
    return s.str() + "-" + x.str();
}

int main()
{
    freopen("knight.inp","r",stdin);
    freopen("knight.out","w",stdout);

    int sx,sy,ex,ey,n;
    cin >> sx >> sy >> ex >> ey;
    cin >> n;
    for (int i = 1; i<=n; i++)
    {
        int r,a,b;
        cin >> r >> a >> b;
        for (int j = a; j<=b; j++) p[doi(r,j)] = true;
    }

    queue<sty> q;
    q.push(sty(sx,sy,0));
    while (!q.empty())
    {
        int u = q.front().x, v = q.front().y, tmp = q.front().bac; q.pop();

        int hang[8] = {-1,-2,-2,-1,1,2, 2, 1};
        int cot[8]  = {-2,-1, 1, 2,2,1,-1,-2};
        for (int i = 0; i<8; i++)
        {
            int x = u+hang[i], y = v+cot[i];
            if (1 <= x && x <= oo && 1 <= y && y <= oo && p[doi(x,y)])
            {
                p[doi(x,y)] = false;
                q.push(sty(x,y,tmp+1));
                if (x == ex && y == ey)
                {
                    cout << tmp + 1;
                    return 0;
                }
            }
        }
    }

    cout << "-1";
    return 0;
}
