#include <iostream>
#include <stdio.h>
#include <math.h>
#include <queue>
#include <string.h>
using namespace std;
#define FOR(i,a,b) for (int i = a; i<=b; i++)

struct sty{
    int x,y;
    sty(int a, int b) {x = a; y = b;}
};

int n,m, h[101][101], a[101][101];

int Min(int u, int v){
    return min(min(a[u-1][v], a[u+1][v]) , min(a[u][v-1], a[u][v+1]));
}

void solve(int x, int y){
    queue<sty> q;
    bool fre[n][m];
    memset(fre,true,sizeof(fre));
    q.push(sty(x,y));
    fre[x][y] = false;

    while (!q.empty()){
        int hang[4] = {-1,0,1, 0};
        int cot[4]  = { 0,1,0,-1};
        int x = q.front().x, y = q.front().y; q.pop();

        FOR(i,0,3){
            int u = x + hang[i], v = y + cot[i];
            if (0 < u && u <= n && 0 < v && v <= m && fre[u][v]){
                fre[u][v] = false;
                q.push(sty(u,v));
                a[u][v] = max(h[u][v], Min(u,v));
            }
        }
    }
}

void PRI(){ FOR(i,1,n){ FOR(j,1,m) cout << a[i][j] << " "; cout << endl;} cout << endl;}

int main(){
    freopen("WOD.inp","r",stdin);
    freopen("WOD.out","w",stdout);

    int nmax = 0;
    cin >> n >> m;
    FOR(i,1,n) FOR(j,1,m){
        cin >> h[i][j];
        nmax = max(nmax, h[i][j]);
    }
    FOR(i,1,n) FOR(j,1,m) a[i][j] = nmax;

    FOR(i,1,n){
        a[i][1] = h[i][1];
        solve(i,1); //PRI();
        a[i][m] = h[i][m];
        solve(i,m); //PRI();
    }
    FOR(i,1,m){
        a[1][i] = h[1][i];
        solve(1,i); //PRI();
        a[n][i] = h[n][i];
        solve(n,i); //PRI();
    }

    long long ans = 0;
    FOR(i,1,n) FOR(j,1,m) if (a[i][j] != h[i][j]) ans += a[i][j] - h[i][j];
    cout << ans;

    return 0;
}
