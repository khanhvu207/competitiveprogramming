#include <iostream>
#include <stdio.h>
#include <vector>
#include <string.h>

using namespace std;

#define dp(u, d) dp[u][d + 300]
#define oo 1e9
#define mask(u) (c[u] ? -1 : 1)

int n, c[300], dp[300][601];
vector <int> a[300];

int solve(int u, int d) {
    if (max(d, -d) > n) return oo;
    if (dp(u, d) > -1) return dp(u, d);
    if (a[u].size()) {
        dp(u, d) = d ? oo : 1;
        if (a[u].size() == 1) dp(u, d) = min(dp(u, d), solve(a[u][0], d + mask(u)));
        else for (int i = -n; i <= n; i++) dp(u, d) = min(dp(u, d), solve(a[u][0], i) + solve(a[u][1], d + mask(u) - i));
    }
    else {
        if (d == 0) dp(u, d) = 1;
        else if ((c[u] && d == 1) || (!c[u] && d == -1)) dp(u, d) = 0;
        else dp(u, d) = oo;
    }
    return dp(u, d);
}

void trace(int u, int d) {
    if (d == 0 && dp(u, d) == 1) cout << u << ' ';
    else if (a[u].size()) {
        if (a[u].size() == 1) trace(a[u][0], d + mask(u));
        else for (int i = -n; i <= n; i++)
            if (solve(a[u][0], i) + solve(a[u][1], d + mask(u) - i) == dp(u, d)) {
                trace(a[u][0], i); trace(a[u][1], d + mask(u) - i); return;
            }
    }
}

int main() {
    freopen("prunef.inp", "r", stdin);
    freopen("prunef.out", "w", stdout);
    int d; cin >> n >> d;
    for (int i = 0; i < n; i++) {
        int u, k; cin >> u; cin >> c[u] >> k;
        for (int i = 0; i < k; i++) {
            int v; cin >> v;
            a[u].push_back(v);
        }
    }
    memset(dp, -1, sizeof dp);
    cout << (solve(0, d) < oo ? dp(0, d) : -1) << '\n';
    if (dp(0, d) < oo) trace(0, d);
}
