// Nguyen Cao Nhat Long
// Pikachuuuuuuuuuuuuu
#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <set>
#include <queue>
#include <vector>
#include <stack>
#include <map>
#include <string>
#include <sstream>
using namespace std;

#define next oapsidfjiuunfiujfa
#define prev sdofljkauohfaodisf

#define sqr(x) ((x)*(x))

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,a) for(int i = 0, _a = (a); i < _a; i++)
#define REPD(i,n) for(int i = (n) - 1; i >= 0; i--)

#define ii pair<int,int>
#define fi first
#define se second
#define mp make_pair

#define sz(x) (int)x.size()
#define ALL(x) (x).begin(), (x).end()
#define MS(a,x) memset(a, x, sizeof(a))

#define sync ios::sync_with_stdio(false)

#define ull unsigned long long
#define ll long long
#define vi vector<int>
#define vll vector<ll>
#define vii vector<ii>
#define pb push_back

#define inf 1000000000
#define INF 100000000000000000LL
#define mod 1000000007LL
#define maxn 310
#define maxq 200003
#define maxa 1000004

#define gg 302 +

int n, req, dp[maxn][2*maxn], one[maxn], zero[maxn], trace[maxn][2*maxn];
bool isOne[maxn];
vi g[maxn];

void dfs(int u)
{
	one[u] = isOne[u];
	zero[u] = !isOne[u];

	vi child;

	REP(i, sz(g[u])) {
		int v = g[u][i];

        child.pb(v);
        dfs(v);
        one[u] += one[v];
        zero[u] += zero[v];
	}

	if(child.empty()) { // leaf
		dp[u][gg 0] = 1;
		if(isOne[u]) dp[u][gg 1] = 0;
		else dp[u][gg -1] = 0;
	}
	else if(sz(child) == 1) { // chinh sach mot con cua Trung Quoc
        dp[u][gg 0] = (one[u] - zero[u] != 0);

		FOR(s, -n, n) { // dp[u][gg s]
			int tmp = isOne[u] == true ? 1 : -1;
			int k = s - tmp; // one - zero

			if(k < -n || k > n) continue;

			if(dp[child[0]][gg k] == inf) continue;
			else dp[u][gg s] = min(dp[u][gg s], dp[child[0]][gg k]);

            if(one[u] - zero[u] == s) dp[u][gg s] = 0;
		}
	}
	else { // ke hoach hoa gia dinh, chinh sach 2 con cua VN
        dp[u][gg 0] = (one[u] - zero[u] != 0);

		FOR(s, -n, n) {
			FOR(k, -n, n) {
				int tmp = isOne[u] == true ? 1 : -1;
				int c1 = child[0], c2 = child[1];
				int need = s - tmp - k;
				if(need < -n || need > n) continue;

				if(dp[c1][gg k] == inf || dp[c2][gg need] == inf) continue;
				else if(dp[u][gg s] > dp[c1][gg k] + dp[c2][gg need]) {
                    dp[u][gg s] = dp[c1][gg k] + dp[c2][gg need];
                    trace[u][gg s] = k;
				}
			}

			if(one[u] - zero[u] == s) dp[u][gg s] = 0;
		}
	}
}

void printTrace(int u, int req)
{
    if(req == 0) {
        if(dp[u][gg 0] == 1) cout << u << ' ';
        return;
    }
    if(sz(g[u]) == 1) {
        if(isOne[u])
            printTrace(g[u][0], req - 1);
        else
            printTrace(g[u][0], req + 1);
    }
    else if(sz(g[u]) == 2) {
        int x = trace[u][gg req];
        printTrace(g[u][0], x);

        if(isOne[u])
            printTrace(g[u][1], req - x - 1);
        else
            printTrace(g[u][1], req - x + 1);
    }
}

int main()
{
	freopen("PRUNEF.INP", "r", stdin);
	freopen("PRUNEF.OUT", "w", stdout);
	ios::sync_with_stdio(false);

	cin >> n >> req;

	FOR(i, 1, n) {
		int u, nChild;
		cin >> u;
		cin >> isOne[u] >> nChild;

		while(nChild--) {
			int v;
			cin >> v;
			g[u].push_back(v);
		}
	}

	FOR(i, 0, n - 1) FOR(j, -302, 302) dp[i][gg j] = inf;

	dfs(0);

//
//    cout << dp[12][gg 0] << '\n';
//    cout << dp[6][gg 0] << '\n';
//    cout << dp[2][gg 0] << '\n';
//    cout << dp[5][gg 0] << '\n';
//
//    cout << dp[3][gg 3] << '\n';
//    cout << dp[1][gg 4] << '\n';
//
//    cout << dp[4][gg 3] << '\n';
//
//    cout << dp[0][gg 8] << '\n';


    /*
    cout << dp[9][gg 0] << '\n';
    cout << dp[5][gg 0] << '\n';
    cout << dp[13][gg 0] << '\n';

    cout << dp[4][gg -2] << '\n';
    cout << dp[6][gg -1] << '\n';
    cout << dp[8][gg 0] << '\n';
    */

	cout << (dp[0][gg req] == inf ? -1 : dp[0][gg req]) << '\n';
	if(dp[0][gg req] != inf)
        printTrace(0, req);
}



