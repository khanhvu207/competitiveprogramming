#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>

#define FOR(i,a,b) for (int i = (a); i <= (b); i++)
#define FORD(i,a,b) for (int i = (a); i >= (b); i--)

using namespace std;

int N;
struct point
{
    int x,y;
    point() {}
    point(int a,int b) {x = a; y = b;}
};
vector <point> a,A;
bool cmp(point a,point b)
{
    if (a.y < b.y) return true; else
    if (a.y > b.y) return false; else return a.x > b.x;
}

void read()
{
    int k;
    scanf("%d",&k);
    while (k--)
    {
        int n;
        scanf("%d",&n);
        N += n + 1;
        FOR(i,1,n + 1)
        {
            int x,y;
            scanf("%d%d",&x,&y);
            if (x < 0) x = -x;
            a.push_back(point(x,y));
        }
    }
    sort(a.begin(),a.end(),cmp);
}

int ccw(point a,point b,point c)
{
    int dx1 = b.x - a.x,dy1 = b.y - a.y,
        dx2 = c.x - a.x,dy2 = c.y - a.y;
    int d = dx1 * dy2 - dx2 * dy1;
    if (d > 0) return 1; else
    if (d < 0) return -1; else
    return 0;
}

void init()
{
    A.push_back(point(a[0]));
    A.push_back(point(a[1]));
    FOR(i,2,N - 1)
    {
        int n = (int)A.size();
        while (n > 1 && ccw(A[n - 2],A[n - 1],a[i]) >= 0) {A.pop_back(); n--;}
        A.push_back(a[i]);
        if (a[i].x == 0) break;
    }
}

double calc(point a,point b)
{
    double A = b.y - a.y,
           B = a.x - b.x;
    if (A == 0 || B == 0) return 0;
    double C = - A * a.x - B * a.y;
    return (C / A) * (C / B);
}

int main()
{
    freopen("SAW.INP","r",stdin);
    freopen("SAW.OUT","w",stdout);
    read();
    init();
    double res = 0;
    FOR(i,0,(int)A.size() - 2) res = max(res,calc(A[i],A[i + 1]));
    printf("%.6lf",res);
    return 0;
}
