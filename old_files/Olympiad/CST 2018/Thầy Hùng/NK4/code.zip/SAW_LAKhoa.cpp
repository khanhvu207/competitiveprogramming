#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,a) for(int i = 0; i < (a); i++)
#define REPD(i,a) for(int i = (a)-1; i >= 0; i--)
#define sz(a) (int)a.size()

using namespace std;

struct point {
    int x, y;
    point() {}
    point(int x, int y) : x(x), y(y) {}
};
typedef point vec;

struct line {
    double a, b, c;
    line() {}
    line(double a, double b, point p) : a(a), b(b) {c = -a*p.x-b*p.y;}
};


point operator + (point a, point b) {return point(a.x+b.x, a.y+b.y);}
point operator - (point a, point b) {return point(a.x-b.x, a.y-b.y);}
point operator * (double k, point a) {return point(k*a.x, k*a.y);}
bool operator == (point a, point b) {return a.x == b.x && a.y == b.y;}

int ccw(point a, point b, point c)
{
    double dt = a.x*(c.y-b.y) + b.x*(a.y-c.y) + c.x*(b.y-a.y);
    if (dt == 0) return 0;
    if (dt < 0) return 1; else return -1;
}

const int N = 1e5+5;

int n;
point P[N];

bool cmp(point a, point b)
{
    return a.y != b.y ? a.y < b.y : a.x > b.x;
}

void convexHull(vector<point> &cwCH)
{
    FOR(i,1,n)
    {
        while (sz(cwCH) >= 2 && ccw(cwCH[sz(cwCH)-2], cwCH[sz(cwCH)-1], P[i]) > 0)
            cwCH.pop_back();
        cwCH.push_back(P[i]);
    }
}

int main()
{
//    cout << ccw(point(2,4),point(3,5),point(1,6));
        freopen("SAW.INP","r",stdin);
        freopen("SAW.OUT","w",stdout);
    int K;
    scanf("%d",&K);
    while (K--)
    {
        int nn;
        scanf("%d",&nn); nn++;
        while (nn--)
        {
            int x, y;
            scanf("%d%d",&x,&y);
            if (x < 0) x = -x;
            P[++n] = point(x,y);
        }
    }
    sort(P+1,P+n+1,cmp);
    int m = n;
    n = 1;
    FOR(i,2,m) if (!(P[i] == P[n])) P[++n] = P[i]; // unique

    vector<point> CH;
    convexHull(CH);

    double res = 0;
    FORD(i,sz(CH)-1,1)
    {
        point p1 = CH[i];
        vec vtcp = CH[i-1]-p1;
        if (vtcp.x > 0 && vtcp.y < 0) // dong nam
        {
            line l(-vtcp.y,vtcp.x,p1);
            res = max(res, -l.c/l.a * -l.c/l.b);
        }
    }
    printf("%.6lf",res);
    return 0;
}
