#include <iostream>
#include <stdio.h>
#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

struct point {
    double x, y;
    point(double xx, double yy) {x = xx; y = yy;}
};

bool cmp(point a, point b) {return a.x > b.x || (a.x == b.x && a.y < b.y);}

bool ccw(point a, point b, point c) {
    return (a.x - b.x)*(a.y - c.y) - (a.y - b.y)*(a.x - c.x) <= 0;
}

double area(point a, point b) {
    return ((b.y - a.y)/(a.x - b.x) * a.x + a.y) * ((a.x - b.x)/(b.y - a.y) * b.y + b.x);
}

int main() {
    freopen("saw.inp", "r", stdin);
    freopen("saw.out", "w", stdout);
    int k;
    cin >> k;
    vector <point> p;
    while (k--) {
        int n;
        cin >> n;
        for (int i = 0; i <= n; i++) {
            int x, y;
            cin >> x >> y;
            p.push_back(point(abs(x), abs(y)));
        }
    }
    sort(p.begin(), p.end(), cmp);
    stack <point> s;
    for (int i = 0; i < p.size(); i++) {
        if (s.size() > 1) {
            point ptmp = s.top(); s.pop();
            if (ccw(s.top(), ptmp, p[i])) s.push(ptmp);
        }
        s.push(p[i]);
    }
    double res = 0;
    point ptmp = s.top(); s.pop();
    bool check = false;
    while (!s.empty()) {
        if (s.top().x != ptmp.x && s.top().y != ptmp.y) {
            if (check || ptmp.x == 0) res = max(res, area(s.top(), ptmp));
            check = true;
        }
        ptmp = s.top(); s.pop();
    }
    printf("%.6f", res);
    return 0;
}
