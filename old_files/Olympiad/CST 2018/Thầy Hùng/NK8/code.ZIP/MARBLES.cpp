#include <iostream>
#include <cstdio>
#include <string>

#define FOR(i,a,b) for (int i = (a); i <= (b); i++)
#define FORD(i,a,b) for (int i = (a); i >= (b); i--)

using namespace std;

const int maxn = 1e5 + 1;
int n,L[maxn],R[maxn],a[maxn * 3];

void read()
{
    string s;
    getline(cin,s);
    n = (int)s.size();
    FOR(i,0,n - 1)
    {
        int x;
        if (s[i] == 'w') x = 0; else
        if (s[i] == 'r') x = -1; else
        if (s[i] == 'b') x = 1;
        a[i] = a[i + n] = a[i + n * 2] = x;
    }
}

int main()
{
    freopen("MARBLES.INP","r",stdin);
    freopen("MARBLES.OUT","w",stdout);
    read();
    int r = n - 1,cl = 0,vt = 0;
    FOR(i,n,n * 2 - 1)
    {
        while ((cl == 0 || a[r] != -cl) && r < n + i)
        {
            r++;
            if (cl == a[r]) vt = r; else
            if (cl == 0) {cl = a[r]; vt = r;} else
            if (a[r] != 0) break;
        }
        R[i - n] = r - i;
        if (i == vt) {cl = -cl; vt = r;}
    }
    int l = 2 * n; cl = 0;
    FORD(i,n * 2 - 1,n)
    {
        while ((cl == 0 || a[l] != -cl) && l > i - n)
        {
            l--;
            if (cl == a[l]) vt = l; else
            if (cl == 0) {cl = a[l]; vt = l;} else
            if (a[l] != 0) break;
        }
        L[i - n] = i - l;
        if (i == vt) {cl = -cl; vt = l;}
    }
    int res = 0;
    FOR(i,0,n - 2) res = max(res,L[i] + R[i + 1]);
    if (res > n) res = n;
    printf("%d",res);
    return 0;
}
