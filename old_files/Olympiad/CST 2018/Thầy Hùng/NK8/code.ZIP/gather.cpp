#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;

int n, x[100010];

long long calc(int m) {
    long long res = 0;
    for (int i = 0; i < n; i++)
        res += abs(m - x[i]);
    return res;
}

int main() {
    freopen("gather.inp", "r", stdin);
    freopen("gather.out", "w", stdout);
    int l = 1e9, r = -1e9;
    cin >> n;
    for (int i = 0; i < n; i++)
        cin >> x[i],
        l = min(l, x[i]),
        r = max(r, x[i]);
    do {
        int m1 = (l + l + r) / 3, m2 = (l + r + r) / 3;
        if (l == m1 || m1 == m2 || m2 == r) break;
        if (calc(m1) >= calc(m2)) l = m1;
        else r = m2;
    } while ("LIFE" != "EASY");
    cout << calc((l + r) / 2);
}
