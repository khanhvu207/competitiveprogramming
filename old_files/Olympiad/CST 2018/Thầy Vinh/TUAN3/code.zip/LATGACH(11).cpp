#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <cstdio>
#include <queue>
#include <iomanip>
#include <stack>
#include <queue>
#include <cstring>
#include <string>
#include <cmath>

using namespace std;

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,n) for(int i = 0; i < n; i++)
#define REPD(i,n) for(int i = n - 1; i >= 0; i--)

#define ALL(x) (x).begin(), (x).end()
#define sz(x) (int)x.size()

#define vi vector<int>
#define vii vector<ii>
#define pb push_back

#define ii pair<int,int>
#define fi first
#define se second
#define mp make_pair

#define ll long long

#define inf 1000000001
#define maxC 100003
#define maxD 102
#define maxK 102
#define maxn 1010

#define gg 1001 +

ll nO, nS;
int n, k, d[2*maxn][2*maxn];
bool obs[2*maxn][2*maxn], visited[2*maxn][2*maxn], IS[2*maxn][2*maxn];
ii DIR[] = {ii(-1,0), ii(0, 1), ii(1,0), ii(0,-1)};

void bfs(int lim, bool flag)
{
    queue<ii> q;    q.push(ii(0, 0));
    FOR(i, -1000, 1000) FOR(j, -1000, 1000)
        d[gg i][gg j] = -1;
    d[gg 0][gg 0] = 0;
    IS[gg 0][gg 0] = true;

    while(!q.empty())
    {
        ii u = q.front();   q.pop();

        if(flag) if(d[gg u.fi][gg u.se] > lim) continue;

        // cout << u.fi << ' ' << u.se << ' ' << d[gg u.fi][gg u.se] << '\n';

        if(u.fi > 1000 || u.fi < -1000 ||
           u.se > 1000 || u.se < -1000) continue;

        if(!obs[gg u.fi][gg u.se]) {
            if(IS[gg u.fi][gg u.se]) nS++;
            else nO++;
        }

        REP(i, 4) {
            ii v;
            v.fi = u.fi + DIR[i].fi;
            v.se = u.se + DIR[i].se;

            if(d[gg v.fi][gg v.se] == -1 && !obs[gg v.fi][gg v.se]) {
                d[gg v.fi][gg v.se] = d[gg u.fi][gg u.se] + 1;
                IS[gg v.fi][gg v.se] = !IS[gg u.fi][gg u.se];
                q.push(v);
            }
        }
    }
}

void diagonal(int i, int j)
{
    if(d[gg i][gg j] == -1) return;

    ll na = (k - d[gg i][gg j]) >> 1;
    ll nb = (k - d[gg i][gg j] - 1) >> 1;

    ll a = na*na;
    ll b = nb*nb + nb;

    if(IS[gg i][gg j]) {
        nS += a;
        nO += b;
    }
    else {
        nS += b;
        nO += a;
    }
}

void calc(int i, int j) {
    if(d[gg i][gg j] != -1) {
        ll a = (k - d[gg i][gg j]) >> 1;
        ll b = (k - d[gg i][gg j] + 1) >> 1;

        if(IS[gg i][gg j]) {
            nO += b;
            nS += a;
        }
        else {
            nO += a;
            nS += b;
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);     cout.tie(0);

    freopen("LATGACH.INP", "r", stdin);
    freopen("LATGACH.OUT", "w", stdout);


    cin >> n >> k;
    FOR(i, 1, n) {
        int y, x;
        cin >> y >> x;

        obs[gg x][gg y] = true;
    }

    if(k <= 1000) {
        bfs(k, true);
        cout << nS << ' ' << nO << '\n';
    }
    else {
        bfs(0, false);

        FOR(i, -1000, -1000) FOR(j, -1000, 1000) calc(i, j);
        FOR(i, 1000, 1000) FOR(j, -1000, 1000) calc(i, j);
        FOR(i, -1000, 1000) FOR(j, -1000, -1000) calc(i, j);
        FOR(i, -1000, 1000) FOR(j, 1000, 1000) calc(i, j);

        diagonal(-1000, -1000);
        diagonal(-1000, 1000);
        diagonal(1000, -1000);
        diagonal(1000, 1000);

        cout << nS << ' ' << nO << '\n';
    }
}
