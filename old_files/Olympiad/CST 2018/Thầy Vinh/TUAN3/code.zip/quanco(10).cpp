#include <iostream>
#include <cstdio>
#include <algorithm>

#define ii pair<int,int>
#define fi first
#define se second
#define maxN 505

using namespace std;
ii a[maxN]; int n;

int abs(int x) { return (x<0) ? -x : x; }

int main()
{
    freopen("quanco.inp","r",stdin);
    freopen("quanco.out","w",stdout);
    scanf("%d",&n);
    for (int i=1; i<=n; i++) scanf("%d%d",&a[i].fi,&a[i].se);
    int res=0;
    sort(a+1,a+n+1);
    for (int i=n; i>0; i--)
    {
        res+=abs(i-a[i].fi);
        a[i].fi=i;
    }
    for (int i=1; i<=n; i++) swap(a[i].fi,a[i].se);
    sort(a+1,a+n+1);
    for (int i=n; i>0; i--)
    {
        res+=abs(i-a[i].fi);
        a[i].fi=i;
    }
    cout<<res;
    return 0;
}
