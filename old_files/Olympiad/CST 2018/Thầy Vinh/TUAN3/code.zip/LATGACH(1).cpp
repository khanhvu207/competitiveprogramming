#include <fstream>
#include <queue>

#define sqr(x) (x)*(x)
#define ii pair<int, int>
#define fi first
#define se second
#define ll long long

using namespace std;

ifstream cin ("LATGACH.inp");
ofstream cout("LATGACH.out");

int n, type[2010][2010];
ll k, cnt[3], d[2010][2010];
int dr[4] = {-1, 0, 1, 0}, dc[4] = {0, 1, 0, -1};
bool blocked[2010][2010];

bool valid(ii u) {
    return 0 <= u.fi && u.fi <= 2002 && 0 <= u.se && u.se <= 2002;
}

void bfs() {
    queue<ii> q;
    ii u, v;

    q.push(ii(1001, 1001)); type[1001][1001] = 1; cnt[1] = 1;
    while (!q.empty()) {
        u = q.front(); q.pop();
        if (d[u.fi][u.se] == k) continue;
        for (int i = 0; i < 4; i++) {
            v = ii(u.fi + dr[i], u.se + dc[i]);
            if (valid(v) && !blocked[v.fi][v.se] && !type[v.fi][v.se]) {
                type[v.fi][v.se] = 3 - type[u.fi][u.se];
                d[v.fi][v.se] = d[u.fi][u.se] + 1;
                cnt[type[v.fi][v.se]]++;
                q.push(v);
            }
        }
    }
}

void process_line(int r, int c) {
    if (d[r][c] < k) {
        ll delta = k - d[r][c];
        cnt[type[r][c]] += (delta) / 2LL;
        cnt[3 - type[r][c]] += (delta + 1LL) / 2LL;
    }
}

ll smallerEven(ll x) {
    return (x & 1LL) ? (x - 1LL) : (x);
}

ll smallerOdd (ll x) {
    return (x & 1LL) ? (x) : (x - 1LL);
}

void process_diagonal(int r, int c) {
    if (d[r][c] < k - 1) {
        ll delta = k - 1 - d[r][c];
        cnt[type[r][c]] += sqr(smallerOdd(delta) + 1LL) / 4LL;
        cnt[3 - type[r][c]] += (sqr(smallerEven(delta) + 1LL) - 1LL) / 4LL;
    }
}

void process() {
    for (int i = 0; i <= 2002; i++) {
        process_line(i, 0);
        process_line(i, 2002);
        process_line(0, i);
        process_line(2002, i);
    }
    process_diagonal(0, 0);
    process_diagonal(0, 2002);
    process_diagonal(2002, 0);
    process_diagonal(2002, 2002);
}

int main()
{
    int x, y;
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> y >> x;
        blocked[x + 1001][y + 1001] = true;
    }

    bfs();
    process();

    cout << cnt[1] << " " << cnt[2];
    return 0;
}
