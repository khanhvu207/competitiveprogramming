#include <cstdio>
#include <queue>
#include <algorithm>

typedef long long ll;
const int N=2020, shift=N/2, inf=1e9,                               stop=1001;
const int dr[4] = {-1,0,1,0},
          dc[4] = {0,-1,0,1};
int n,k;
bool _a[N][N];
int _d[N][N];

bool &a (int r, int c) {return _a[r+shift][c+shift];}
int &d (int r,int c) {return _d[r+shift][c+shift];}

ll evenDist=0ll, oddDist=0ll;

void input () {
    scanf("%d %d\n",&n,&k);
    for (int i=1;i<=n;i++) {
        int r,c; scanf("%d %d\n",&c,&r);
        a(r,c) = 1;
    }
}
bool inside (int r,int c) {return r>=-stop && r<=stop && c>=-stop && c<=stop;}
void InBorder_Process () {
    for (int i=0;i<N;i++) for (int j=0;j<N;j++) _d[i][j]=inf;
    std::queue <int> Qr, Qc; Qr.push(0); Qc.push(0); d(0,0)=0; evenDist++;
    while (!Qr.empty() && !Qc.empty()) {
        int r=Qr.front(), c=Qc.front();
        Qr.pop(); Qc.pop();
        if (d(r,c) == k) break;
        for (int dir=0;dir<4;dir++) {
            int nr=r+dr[dir], nc=c+dc[dir];
            if (!a(nr,nc) && d(nr,nc)==inf && inside(nr,nc)) {
                d(nr, nc) = d(r,c) + 1;
                if (d(nr,nc)&1) oddDist++; else evenDist++;
                Qr.push(nr); Qc.push(nc);
            }
        }
    }
}
void Corner_Process (int r,int c) {
    if (d(r,c) + 1 < k) {
        ll dist = (ll)k - d(r,c) - 1;
        if (!(d(r,c)&1)) { //Chan spawn dau tien
            evenDist+= (dist&1) ? (dist-1)*(dist-1)/4 + (dist-1)/2 + (dist+1)/2
                                : (dist-2)*(dist-2)/4 + (dist-2)/2 + dist/2;
            oddDist += (dist&1) ? (dist-1)*(dist-1)/4 + (dist-1)/2
                                : (dist*dist)/4 + dist/2;
        }
        else { //Le spawn dau tien
            evenDist += (dist&1) ? (dist-1)*(dist-1)/4 + (dist-1)/2
                                 : (dist*dist)/4 + dist/2;
            oddDist  += (dist&1) ? (dist-1)*(dist-1)/4 + (dist-1)/2 + (dist+1)/2
                                 : (dist-2)*(dist-2)/4 + (dist-2)/2 + dist/2;
        }
    }
}
void Straight_Process (int r, int c) {
    if (d(r,c)<k) {
        ll num_cell = (ll)k - d(r,c);
        if (d(r,c)&1) {oddDist+=num_cell/2; evenDist+=(num_cell+1)/2;}
        else {evenDist+=num_cell/2; oddDist+=(num_cell+1)/2;}
    }
}
void OutBorder_Process () {
    int r,c;
    //Cac duong thang ben ngoai.
    r = -stop;
    for (c = -stop; c<=stop; c++)
        Straight_Process(r, c);

    c = -stop;
    for (r = -stop; r<=stop; r++)
        Straight_Process(r, c);

    r = stop;
    for (c = -stop; c<=stop; c++)
        Straight_Process(r, c);

    c = stop;
    for (r = -stop; r<=stop; r++)
        Straight_Process(r, c);

    //Cac duong cheo.
    Corner_Process(-stop, -stop);
    Corner_Process(-stop, stop);
    Corner_Process(stop, -stop);
    Corner_Process(stop, stop);
}

int main() {
    freopen("latgach.inp","r",stdin); freopen("latgach.out","w",stdout); //*/
    input ();
    InBorder_Process ();
    OutBorder_Process ();
    printf("%lld %lld\n",evenDist,oddDist);
    return 0;
}
