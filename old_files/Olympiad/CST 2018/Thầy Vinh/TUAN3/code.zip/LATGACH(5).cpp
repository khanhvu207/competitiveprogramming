#include <iostream>
#include <cstdio>
#include <queue>

#define ll long long

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)
#define REP(i,a) for(int i = 0; i < (a); i++)
#define sz(a) (int)a.size()

#define ii pair<int,int>
#define fi first
#define se second

using namespace std;

const int N = 2005;
const int td[4] = {0,0,1,-1};
const int tc[4] = {1,-1,0,0};

int n, K, xmax, xmin, ymin, ymax;
int a[N][N], d[N][N];
ll cnt[2];

bool inside(int i, int j)
{
    return (i >= xmin && i <= xmax && j >= ymin && j <= ymax);
}

void bfs()
{
    queue<ii> q;
    q.push(ii(1001,1001));
    FOR(i,xmin,xmax) FOR(j,ymin,ymax) d[i][j] = -1;
    d[1001][1001] = 0;
    while (sz(q))
    {
        ii tmp = q.front(); q.pop();
        int ud = tmp.fi, uc = tmp.se;
        cnt[d[ud][uc]&1]++;
        if (d[ud][uc] == K) continue;
        REP(k,4)
        {
            int vd = ud + td[k], vc = uc + tc[k];
            if (inside(vd,vc) && !a[vd][vc] && d[vd][vc] == -1)
            {
                d[vd][vc] = d[ud][uc] + 1;
                q.push(ii(vd,vc));
            }
        }
    }
}

void Line(int D)
{
    if (D < 0) return;
    ll tmp = (K-D)/2;
    cnt[0] += tmp;
    cnt[1] += tmp;
    if ((K&1) != (D&1))
    {
        if (K&1) cnt[1]++; else cnt[0]++;
    }
}

void Triangle(int D)
{
    if (D < 0) return;
    ll tmp = (K-D)/2;
    cnt[D&1] += tmp*tmp;
    cnt[1-(D&1)] += 1LL*(K-D-1)*(K-D)/2 - tmp*tmp;
}

int main()
{
        freopen("LATGACH.INP","r",stdin);
        freopen("LATGACH.OUT","w",stdout);
    scanf("%d%d",&n,&K);
    xmax = ymax = 1001;
    xmin = ymin = 1001;
    FOR(i,1,n)
    {
        int x, y;
        scanf("%d%d",&y,&x);
        x += 1001;
        y += 1001;
        a[x][y] = true;
        xmax = max(xmax,x+1);
        xmin = min(xmin,x-1);
        ymax = max(ymax,y+1);
        ymin = min(ymin,y-1);
    }
    bfs();
    FOR(i,ymin,ymax)
    {
        Line(d[xmin][i]);
        Line(d[xmax][i]);
    }
    FOR(i,xmin,xmax)
    {
        Line(d[i][ymin]);
        Line(d[i][ymax]);
    }
    Triangle(d[xmin][ymin]);
    Triangle(d[xmin][ymax]);
    Triangle(d[xmax][ymin]);
    Triangle(d[xmax][ymax]);
    cout << cnt[0] << " " << cnt[1];
    return 0;
}
