#include <iostream>
#include <cstdio>
#include <algorithm>

#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define FORD(i,a,b) for(int i = (a); i >= (b); i--)

#define ii pair<int,int>
#define fi first
#define se second

using namespace std;

const int N = 505;

int n;
ii a[N];

bool cmp(ii a, ii b)
{
    return a.se < b.se;
}

int ABS(int x)
{
    return x < 0 ? -x : x;
}

int main()
{
        freopen("QUANCO.INP","r",stdin);
        freopen("QUANCO.OUT","w",stdout);
    scanf("%d",&n);
    FOR(i,1,n) scanf("%d%d",&a[i].fi,&a[i].se);
    sort(a+1,a+n+1);
    int res = 0;
    FOR(i,1,n)
    {
        res += ABS(i-a[i].fi);
        a[i].fi = i;
    }
    sort(a+1,a+n+1,cmp);
    FOR(i,1,n)
    {
        res += ABS(i-a[i].se);
        a[i].se = i;
    }
    cout << res;
    return 0;
}
