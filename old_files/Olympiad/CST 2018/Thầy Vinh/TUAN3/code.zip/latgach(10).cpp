#include <iostream>
#include <cstdio>
#include <queue>

#define ii pair<int,int>
#define fi first
#define se second
#define maxN 2010
#define ll long long

using namespace std;
int d[maxN][maxN],n,K,dd[]={1,-1,0,0},cc[]={0,0,1,-1}; bool obsta[maxN][maxN],visited[maxN][maxN]; queue<ii>q;

int main()
{
    int u,v;
    freopen("latgach.inp","r",stdin);
    freopen("latgach.out","w",stdout);
    scanf("%d%d",&n,&K);
    int Minx=1004,Miny=1004,Maxx=1006,Maxy=1006;
    for (int i=1; i<=n; i++)
    {
        scanf("%d%d",&u,&v);
        u+=1005; v+=1005;
        obsta[u][v]=true;
        Minx=min(Minx,u-1);
        Miny=min(Miny,v-1);
        Maxx=max(Maxx,u+1);
        Maxy=max(Maxy,v+1);
    }
    q.push(ii(1005,1005));
    ll cnt1=0,cnt2=0;
    visited[1005][1005]=true;
    while (!q.empty())
    {
        ii tmp=q.front(); q.pop();
        u=tmp.fi,v=tmp.se;
        if (d[u][v]%2==0) cnt1++;
        else cnt2++;
        if (d[u][v]==K) continue;
        for (int i=0; i<4; i++)
        {
            int u1=u+dd[i],v1=v+cc[i];
            if (u1>=Minx && u1<=Maxx && v1>=Miny && v1<=Maxy && !visited[u1][v1] && !obsta[u1][v1])
            {
                visited[u1][v1]=true;
                d[u1][v1]=d[u][v]+1;
                q.push(ii(u1,v1));
            }
        }
    }
    for (int i=Minx; i<=Maxx; i++)
    {
        if (visited[i][Miny])
        {
            if (d[i][Miny]%2==0)
            {
                cnt1+=1LL*(K-d[i][Miny])/2;
                cnt2+=1LL*(K-d[i][Miny]+1)/2;
            }
            else
            {
                cnt1+=1LL*(K-d[i][Miny]+1)/2;
                cnt2+=1LL*(K-d[i][Miny])/2;
            }
        }
        if (visited[i][Maxy])
        {
            if (d[i][Maxy]%2==0)
            {
                cnt1+=1LL*(K-d[i][Maxy])/2;
                cnt2+=1LL*(K-d[i][Maxy]+1)/2;
            }
            else
            {
                cnt1+=1LL*(K-d[i][Maxy]+1)/2;
                cnt2+=1LL*(K-d[i][Maxy])/2;
            }
        }
    }
    for (int i=Miny; i<=Maxy; i++)
    {
        if (visited[Minx][i])
        {
            if (d[Minx][i]%2==0)
            {
                cnt1+=1LL*(K-d[Minx][i])/2;
                cnt2+=1LL*(K-d[Minx][i]+1)/2;
            }
            else
            {
                cnt1+=1LL*(K-d[Minx][i]+1)/2;
                cnt2+=1LL*(K-d[Minx][i])/2;
            }
        }
        if (visited[Maxx][i])
        {
            if (d[Maxx][i]%2==0)
            {
                cnt1+=1LL*(K-d[Maxx][i])/2;
                cnt2+=1LL*(K-d[Maxx][i]+1)/2;
            }
            else
            {
                cnt1+=1LL*(K-d[Maxx][i]+1)/2;
                cnt2+=1LL*(K-d[Maxx][i])/2;
            }
        }
    }
//    cout<<cnt1<<' '<<cnt2<<'\n';
    if (visited[Minx][Miny])
    {
        ll tmp1=1LL*(K-d[Minx][Miny])/2;
        ll tmp2=1LL*(K-d[Minx][Miny]-1)/2;
        if (d[Minx][Miny]%2==0)
        {
            cnt1+=tmp1*tmp1;
            cnt2+=tmp2*(tmp2+1);
        }
        else
        {
            cnt2+=tmp1*tmp1;
            cnt1+=tmp2*(tmp2+1);
        }
//        cout<<cnt1<<' '<<cnt2<<'\n';
    }
    if (visited[Minx][Maxy])
    {
        ll tmp1=1LL*(K-d[Minx][Maxy])/2;
        ll tmp2=1LL*(K-d[Minx][Maxy]-1)/2;
        if (d[Minx][Maxy]%2==0)
        {
            cnt1+=tmp1*tmp1;
            cnt2+=tmp2*(tmp2+1);
        }
        else
        {
            cnt2+=tmp1*tmp1;
            cnt1+=tmp2*(tmp2+1);
        }
//        cout<<cnt1<<' '<<cnt2<<'\n';
    }
    if (visited[Maxx][Miny])
    {
        ll tmp1=1LL*(K-d[Maxx][Miny])/2;
        ll tmp2=1LL*(K-d[Maxx][Miny]-1)/2;
        if (d[Maxx][Miny]%2==0)
        {
            cnt1+=tmp1*tmp1;
            cnt2+=tmp2*(tmp2+1);
        }
        else
        {
            cnt2+=tmp1*tmp1;
            cnt1+=tmp2*(tmp2+1);
        }
//        cout<<cnt1<<' '<<cnt2<<'\n';
    }
    if (visited[Maxx][Maxy])
    {
        ll tmp1=1LL*(K-d[Maxx][Maxy])/2;
        ll tmp2=1LL*(K-d[Maxx][Maxy]-1)/2;
        if (d[Maxx][Maxy]%2==0)
        {
            cnt1+=tmp1*tmp1;
            cnt2+=tmp2*(tmp2+1);
        }
        else
        {
            cnt2+=tmp1*tmp1;
            cnt1+=tmp2*(tmp2+1);
        }
//        cout<<cnt1<<' '<<cnt2<<'\n';
    }
    cout<<cnt1<<' '<<cnt2;
    return 0;
}
