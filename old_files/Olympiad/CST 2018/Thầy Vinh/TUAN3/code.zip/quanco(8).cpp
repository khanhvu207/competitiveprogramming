#include <cstdio>
#include <cmath>
#include <algorithm>

const int N=501;
struct xy {
    int r,c;
} a[N];
int n;
bool cmpA (xy i, xy j) {return i.r<j.r;}
bool cmpB (xy i, xy j) {return i.c<j.c;}
void input () {
    scanf("%d\n",&n);
    for (int i=1;i<=n;i++)
        scanf("%d %d\n",&a[i].r,&a[i].c);
}


int main () {
    freopen("quanco.inp","r",stdin); freopen("quanco.out","w",stdout); //*/
    input();
    std::sort(a+1, a+n+1, cmpA);
    int ans = 0;
    for (int i=1;i<=n;i++) {
        ans += abs(a[i].r - i);
        a[i].r = i;
    }
    std::sort (a+1, a+n+1, cmpB);
    for (int i=1;i<=n;i++) {
        ans += abs(a[i].c - i);
        a[i].c = i;
    }
    printf("%d",ans);
    return 0;
}
