#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <queue>
#include <string.h>

#define nmax 1000100
using namespace std;
typedef long long ll;

int n,k, smax;
vector<int> a[nmax];
bool kt[nmax], fre[nmax];
queue<int> q,p;

int main()
{
    freopen("food.inp","r",stdin);
    freopen("food.OUT","w",stdout);

    cin >> n >> k;
    memset(fre,true,sizeof(fre));
    for (int i = 1; i<=n; i++)
    {
        string s; cin >> s;
        ll u = 0;
        for (int i = 0; i<k; i++)
            if (s[k-1-i] == '1') u += 1 << i;
        q.push(u); fre[u] = false; p.push(0);
    }

    int u, smax = 0;
    while (!q.empty())
    {
        u = q.front(); q.pop();
        int d = p.front(); p.pop();
        for (int i = 0; i < k; i++)
        {
            int t = u xor (1 << i);
            if (fre[t])
            {
                q.push(t); fre[t] = false; p.push(d+1);
                if (d+1 > smax) smax = d+1;
            }
        }
    }

    cout << k-smax;
    return 0;
}
