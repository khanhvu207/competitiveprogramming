#include <iostream>
#include <cstdio>
#include <queue>

#define ii pair<int,int>
#define iii pair<int,ii>
#define fi first
#define se second
#define maxN 1005
#define mp make_pair

using namespace std;
int dd[]={1,0,-1,0},cc[]={0,-1,0,1},n,m; char a[maxN][maxN]; bool b[maxN][maxN];

int BFS(int x,int y,int dir)
{
    queue<iii> q;
    b[x][y]=1;
    q.push(mp(x,ii(y,dir)));
    int cnt=0;
    while (!q.empty())
    {
        iii tmp=q.front(); q.pop();
        int u=tmp.fi,v=tmp.se.fi,cur=tmp.se.se;
        u+=dd[cur]; v+=cc[cur];
        if (u>m || u<1 || v>n || v<1)
        {
            b[u][v]=1;
            break;
        }
        cnt++;
        if (a[u][v]=='/')
        {
            if (cur==0) cur=1;
            else if (cur==1) cur=0;
            else if (cur==2) cur=3;
            else if (cur==3) cur=2;
            q.push(mp(u,ii(v,cur)));
        }
        else if (a[u][v]=='\\')
        {
            if (cur==0) cur=3;
            else if (cur==1) cur=2;
            else if (cur==2) cur=1;
            else if (cur==3) cur=0;
            q.push(mp(u,ii(v,cur)));
        }
    }
    return cnt;
}

int main()
{
    freopen("mirror.inp","r",stdin);
    freopen("mirror.out","w",stdout);
    scanf("%d%d\n",&m,&n);
    for (int i=1; i<=m; i++)
    {
        scanf("%s",a[i]);
        for (int j=n-1; j>=0; j--) a[i][j+1]=a[i][j];
    }
    int res=0;
    for (int i=1; i<=n; i++) if (!b[0][i]) res=max(res,BFS(0,i,0));
    for (int i=1; i<=n; i++) if (!b[m+1][i]) res=max(res,BFS(m+1,i,2));
    for (int i=1; i<=m; i++) if (!b[i][0]) res=max(res,BFS(i,0,3));
    for (int i=1; i<=m; i++) if (!b[i][n+1]) res=max(res,BFS(i,n+1,1));
    cout<<res;
    return 0;
}
