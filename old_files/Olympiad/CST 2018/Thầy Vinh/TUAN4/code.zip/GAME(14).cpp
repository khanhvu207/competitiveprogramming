#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    freopen("GAME.INP","r",stdin);
    freopen("GAME.OUT","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int i,j,n,m;
    int ans = 0,col[1001] = {0};
    char c;
    cin >> n >> m;
    for (i = 0; i < n; i++)
        for (j = 0; j < m; j++)
        {
            cin >> c;
            if (c == '#') col[j]++;
        }
    for (j = 0; j < m; j++)
        if (col[j] == 0) ans++;
    cout << ans;
    return 0;
}
