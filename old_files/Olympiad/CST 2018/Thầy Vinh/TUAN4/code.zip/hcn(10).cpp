#include <iostream>
#include <cstdio>
#include <set>

#define maxN 1005
#define ii pair<int,int>
#define iii pair<int,ii>
#define iiii pair<int,iii>
#define fi first
#define se second

using namespace std;
iiii a[maxN]; int n,p[maxN];

int Find(int x) { return (p[x]==0) ? x : p[x]=Find(p[x]); }

bool chich(int x,int y)
{
    if (a[x].se.se.fi<a[y].fi || a[x].se.se.se<a[y].se.fi || a[x].fi>a[y].se.se.fi || a[x].se.fi>a[y].se.se.se) return false;
    if (a[x].fi<a[y].fi && a[x].se.fi<a[y].se.fi && a[x].se.se.fi>a[y].se.se.fi && a[x].se.se.se>a[y].se.se.se) return false;
    swap(x,y);
    if (a[x].fi<a[y].fi && a[x].se.fi<a[y].se.fi && a[x].se.se.fi>a[y].se.se.fi && a[x].se.se.se>a[y].se.se.se) return false;
    return true;
}

int main()
{
    freopen("hcn.inp","r",stdin);
    freopen("hcn.out","w",stdout);
    scanf("%d",&n);
    for (int i=1; i<=n; i++) scanf("%d%d%d%d",&a[i].fi,&a[i].se.fi,&a[i].se.se.fi,&a[i].se.se.se);
    for (int i=1; i<=n; i++)
    {
        for (int j=i+1; j<=n; j++) if (chich(i,j))
        {
            int u=Find(i),v=Find(j);
            if (u!=v) p[v]=u;
        }
    }
    set<int> S;
    for (int i=1; i<=n; i++)
    {
        int u=Find(i);
        S.insert(u);
    }
    cout<<S.size();
    return 0;
}
