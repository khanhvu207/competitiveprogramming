#include <fstream>

const int N=1000;
const int dr[4] = {0,1,0,-1},
          dc[4] = {-1,0,1,0};
char a[N][N];
int row, col;
bool visited[N][N];
std::ifstream fin("game.inp"); std::ofstream fout ("game.out");
void input () {
    fin >> row >> col;
    for (int i=0;i<row;i++)
        for (int j=0;j<col;j++) fin>>a[i][j];
}
bool inside (int r,int c) {return r>=0 && r<row && c>=0 && c<col;}
bool visit (int r, int c) {
    visited[r][c] = 1;
    if (r == row-1) return 1;
    for (int k=0;k<4;k++) {
        int nr=r+dr[k], nc=c+dc[k];
        if (inside(nr, nc) && a[nr][nc]=='.' && !visited[nr][nc]) {
            bool tmp = visit(nr, nc);
            if (tmp) return 1;
        }
    }
    return 0;
}

int main() {
    input ();
    int ans = 0;
    for (int i=0;i<col;i++)
    if (a[0][i]=='.' && !visited[0][i]){
        if (visit(0,i)) ans++;
    }
    fout << ans;
    return 0;
}
