#include <iostream>
#include <stdio.h>
#include <queue>
#include <string.h>

using namespace std;

struct data {
    int x, y, d;
    data(int xx, int yy, int dd) {
        x = xx; y = yy; d = dd;
    }
    bool operator < (data x) const {
        return d > x.d;
    }
};

int main() {
    freopen("game.inp", "r", stdin);
    freopen("game.out", "w", stdout);
    int m, n;
    cin >> m >> n;
    string Map[m];
    for (int i = 0; i < m; i++)
        cin >> Map[i];
    priority_queue <data> heap;
    bool visited[m][n];
    memset(visited, false, sizeof visited);
    int gox[8] = {-1, -1, 0, 1, 1, 1, 0, -1}, goy[8] = {0, 1, 1, 1, 0, -1, -1, -1};
    for (int i = 1; i < m-1; i++) heap.push(data(i, 0, Map[i][0] != '#'));
    while ("LIFE" != "EASY") {
        int x = heap.top().x, y = heap.top().y, d = heap.top().d;
        heap.pop();
        if (visited[x][y]) continue;
        visited[x][y] = true;
        if (y == n-1) {
            cout << d;
            return 0;
        }
        for (int i = 0; i < 8; i++) {
            int u = x + gox[i], v = y + goy[i];
            if (0 < u && u < m-1 && 0 <= v && v < n && !visited[u][v])
                heap.push(data(u, v, d + (Map[u][v] != '#')));
        }
    }
}
