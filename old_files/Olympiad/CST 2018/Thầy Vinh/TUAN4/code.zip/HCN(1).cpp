#include <iostream>
#include <cstdio>

#define maxN 1010

using namespace std;

struct square {
    int x1, y1, x2, y2;
    square() {x1 = y1 = x2 = y2 = 0;}
    square(int _x1, int _y1, int _x2, int _y2) {x1 = _x1; y1 = _y1; x2 = _x2; y2 = _y2;}
};

int n;
square sq[maxN];
int p[maxN], cnt[maxN];

void initSet() {
    for (int i = 1; i <= n; i++) {
        p[i] = i;
        cnt[i] = 1;
    }
}

int findSet(int u) {
    return u == p[u] ? u : (p[u] = findSet(p[u]));
}

void unionSet(int x, int y) {
    if (cnt[x] > cnt[y]) {
        p[y] = x;
        cnt[x] += cnt[y];
        cnt[y] = 0;
    } else {
        p[x] = y;
        cnt[y] += cnt[x];
        cnt[x] = 0;
    }
}

bool inBetween(int l, int r, int k) {
    if (l > r) swap(l, r);
    return l <= k && k <= r;
}

bool squareIntersect(square btm, square top) {
    if (inBetween(top.x1, top.x2, btm.x1) && inBetween(btm.y1, btm.y2, top.y1))return true;
    if (inBetween(top.x1, top.x2, btm.x2) && inBetween(btm.y1, btm.y2, top.y1))return true;

    if (inBetween(top.x1, top.x2, btm.x1) && inBetween(btm.y1, btm.y2, top.y2))return true;
    if (inBetween(top.x1, top.x2, btm.x2) && inBetween(btm.y1, btm.y2, top.y2))return true;

    if (inBetween(top.y1, top.y2, btm.y1) && inBetween(btm.x1, btm.x2, top.x1))return true;
    if (inBetween(top.y1, top.y2, btm.y2) && inBetween(btm.x1, btm.x2, top.x1))return true;

    if (inBetween(top.y1, top.y2, btm.y1) && inBetween(btm.x1, btm.x2, top.x2))return true;
    if (inBetween(top.y1, top.y2, btm.y2) && inBetween(btm.x1, btm.x2, top.x2))return true;

    return false;
}

int main() {
    freopen("HCN.inp", "r", stdin);
    freopen("HCN.out", "w", stdout);

    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%d%d%d%d", &sq[i].x1, &sq[i].y1, &sq[i].x2, &sq[i].y2);

    initSet();
    int x, y;
    for (int i = 1; i < n; i++)
        for (int j = i + 1; j <= n; j++)
            if ((x = findSet(i)) != (y = findSet(j)))
                if (squareIntersect(sq[i], sq[j]) || squareIntersect(sq[j], sq[i]))
                    unionSet(x, y);

    int res = 0;
    for (int i = 1; i <= n; i++) res += (cnt[i] > 0);
    printf("%d", res);

    return 0;
}
