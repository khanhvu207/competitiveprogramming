#include <iostream>
#include <cstdio>
#include <queue>
using namespace std;
#define ii pair<int,int>
#define iii pair<int,ii>
#define fi first
#define se second

vector<ii> a[10001];
long long d[10001][21];
int n,m,k;

int main()
{
    freopen("ttp.inp","r",stdin);
    freopen("ttp.out","w",stdout);

    cin >> n  >> m >> k;
    while (m--){
        int u,v,c;
        cin >> u >> v >> c;
        a[u].push_back(ii(v,c));
        a[v].push_back(ii(u,c));
    }

    priority_queue<iii, vector<iii>, greater<iii> > q;  q.push(make_pair(0,ii(1,0)));
    for (int i = 1; i<=n; i++)
        for (int j = 0; j<=k; j++) d[i][j] = long(1e15);
    d[1][0] = 0;

    bool yes = false;
    while (!q.empty()){
        int u = q.top().se.fi, tmp = q.top().se.se;
        if (u == n){
            yes = true;
            break;
        }
        q.pop();

        for (int i = 0; i < a[u].size(); i++){
            int v = a[u][i].fi;
            if (d[v][tmp] > d[u][tmp] + a[u][i].se){
                d[v][tmp] = d[u][tmp] + a[u][i].se;
                q.push(make_pair(d[v][tmp] , ii(v,tmp)));
            }
            if (tmp < k && d[v][tmp+1] > d[u][tmp]){
                d[v][tmp+1] = d[u][tmp];
                q.push(make_pair(d[v][tmp+1], ii(v,tmp+1)));
            }
        }
    }

    if (!yes) cout << "-1\n";
    else{
            int smin = long(1e15);
            for (int i = 0; i<=k; i++) if (smin > d[n][i]) smin = d[n][i];
            cout << smin << "\n";
        }

    return 0;
}
