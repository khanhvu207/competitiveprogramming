#include <iostream>
#include <stdio.h>
#include <vector>
#include <queue>
using namespace std;
#define ii pair<int,int>
#define iii pair<int,ii>
#define fi first
#define se second

int n,m,k, d[1100][1100];
vector<ii> a[1100];

void init(){
    cin >> n >> m >> k;
    k = min(k,m);
    for (int i = 0; i<m; i++)
    {
        int u,v,l;
        cin >> u >> v >> l;
        a[u].push_back(ii(v,l));
        a[v].push_back(ii(u,l));
    }
}

int main(){
    freopen("YEUCAU.inp","r",stdin);
    freopen("YEUCAU.OUT","w",stdout);
    init();

    priority_queue<iii, vector<iii>, greater<iii> > q;
    for (int i = 1; i<=n; i++)
        for (int j = 0; j <= k; j++) d[i][j] = long(1e15);
    q.push(make_pair(0,ii(1,0)));
    d[1][0] = 0;

    while (!q.empty())
    {
        int u = q.top().se.fi, tmp = q.top().se.se; q.pop();
        for (int i = 0; i < a[u].size(); i++)
        {
            int v = a[u][i].fi;
            if (d[v][tmp] > max(d[u][tmp], a[u][i].se))	
            {
                d[v][tmp] = max(d[u][tmp], a[u][i].se);
                q.push(make_pair(d[v][tmp], ii(v,tmp)));
            }
            if (tmp < k && d[u][tmp] < d[v][tmp+1])
            {
                d[v][tmp+1] = d[u][tmp];
                q.push(make_pair(d[v][tmp+1], ii(v,tmp+1)));
            }
        }
    }

    int ans = long(1e9);
    for (int i = 0; i <= k; i++)  ans = min(ans, d[n][i]);
    if (ans == long(1e9)) cout << "-1\n"; else printf("%d\n", ans);
    return 0;
}
